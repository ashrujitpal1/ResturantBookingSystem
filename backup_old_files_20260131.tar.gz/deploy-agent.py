#!/usr/bin/env python3
"""Deploy agent using Runtime SDK (from notebook pattern)"""

from bedrock_agentcore_starter_toolkit.notebook import Runtime
from unittest.mock import patch
import os

print("🚀 Deploying Restaurant Booking Agent to AgentCore...")

# Auto-answer prompts (from notebook pattern)
def mock_prompt(text, default=""):
    print(f"Auto-answering: {text}")
    if "memory" in text.lower():
        return "no"  # Disable long-term memory prompts
    return default or "no"

# Keep our custom Dockerfile - only remove config files
for file in ['.dockerignore', '.bedrock_agentcore.yaml']:
    if os.path.exists(file):
        os.remove(file)
        print(f"Removed old {file}")

runtime = Runtime()

# Configure with auto-prompts (from notebook)
with patch('bedrock_agentcore_starter_toolkit.cli.common.prompt', side_effect=mock_prompt):
    runtime.configure(
        entrypoint="restaurant_agent_runtime/complete_booking_workflow.py",
        requirements_file="restaurant_agent_runtime/requirements.txt",
        agent_name="restaurant_discovery_agent",
        auto_create_ecr=True,
        execution_role="arn:aws:iam::696072349808:role/restaurant_discovery_agent-runtime-role"
    )

print("📦 Launching agent...")
runtime.launch(auto_update_on_conflict=True)  # Update existing agent

print("\n✅ Deployment complete!")
print("\n🧪 Test with:")
print("   python3 test_deployed_agent.py")
print("\nOr invoke directly:")
print("   runtime.invoke(payload={'prompt': 'Find Italian restaurants'})")
