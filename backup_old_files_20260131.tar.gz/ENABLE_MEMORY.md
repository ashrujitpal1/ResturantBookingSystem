# Enable Phase 3: Memory & History

## Quick Start (3 Steps)

### Step 1: Create Memory Store

```bash
# Create memory store via AWS CLI
aws bedrock-agentcore create-memory \
  --memory-name restaurant-booking-memory \
  --retention-days 30 \
  --region us-east-1
```

**Save the output** - you'll need `memoryId` and `memoryArn`:
```json
{
  "memoryId": "mem-abc123xyz",
  "memoryArn": "arn:aws:bedrock-agentcore:us-east-1:696072349808:memory/mem-abc123xyz"
}
```

### Step 2: Update Configuration

Edit `.bedrock_agentcore.yaml`:

```yaml
memory:
  mode: MEMORY_ENABLED  # Change from NO_MEMORY
  memory_id: mem-abc123xyz  # From Step 1
  memory_arn: arn:aws:bedrock-agentcore:us-east-1:696072349808:memory/mem-abc123xyz  # From Step 1
  memory_name: restaurant-booking-memory
  event_expiry_days: 30
  was_created_by_toolkit: true
```

### Step 3: Deploy

```bash
# Set environment variable
export MEMORY_ID=mem-abc123xyz

# Redeploy agent
python deploy_restaurant_agent.py
```

---

## Verification

Test memory functionality:

```python
# Test 1: Save conversation
payload = {
    "prompt": "Book Italian restaurant for tomorrow",
    "user_id": "test_user_123",
    "session_id": "session_001"
}

# Test 2: Retrieve history
payload = {
    "prompt": "show my history",
    "user_id": "test_user_123",
    "session_id": "session_001"
}

# Test 3: Semantic search
payload = {
    "prompt": "show my italian bookings",
    "user_id": "test_user_123"
}
```

Expected response:
```json
{
  "memory_status": "saved",  // or "retrieved"
  "final_response": "# Recent History\n1. Booked Italian Bistro..."
}
```

---

## Alternative: Use AWS Console

1. Go to **AWS Bedrock Console** → **AgentCore** → **Memory Stores**
2. Click **Create Memory Store**
3. Name: `restaurant-booking-memory`
4. Retention: `30 days`
5. Click **Create**
6. Copy `Memory ID` and `Memory ARN`
7. Follow Step 2 and 3 above

---

## Features Enabled

✅ **PII Scrubbing**: Phone, email, cards masked before storage  
✅ **Semantic Search**: "show my Italian bookings"  
✅ **Exact Match**: "find booking_a1b2c3d4"  
✅ **Actor Isolation**: Per-user memory separation  
✅ **30-Day Retention**: Automatic cleanup  
✅ **Encryption**: At rest and in transit (automatic)

---

## Troubleshooting

**Memory not working?**
```bash
# Check environment variable
echo $MEMORY_ID

# Check agent logs
aws logs tail /aws/bedrock-agentcore/restaurant_discovery_agent --follow

# Verify memory store exists
aws bedrock-agentcore describe-memory --memory-id mem-abc123xyz --region us-east-1
```

**Permission errors?**
Add to agent execution role:
```json
{
  "Effect": "Allow",
  "Action": [
    "bedrock-agentcore:SaveConversation",
    "bedrock-agentcore:ListEvents",
    "bedrock-agentcore:GetMemory"
  ],
  "Resource": "arn:aws:bedrock-agentcore:us-east-1:696072349808:memory/*"
}
```
