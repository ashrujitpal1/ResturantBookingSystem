#!/usr/bin/env python3
"""Test locally running agent on port 9000"""
import requests
import json
import time

BASE_URL = "http://localhost:9000"

def test_health():
    """Test health endpoint"""
    print("🏥 Testing health endpoint...")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}\n")
    return response.status_code == 200

def test_restaurant_search():
    """Test Phase 1: Restaurant Search"""
    print("🔍 Testing Restaurant Search (Phase 1)...")
    payload = {
        "correlation_id": "local-test-001",
        "user_id": "test-user-123",
        "session_id": "local-session-001",
        "user_message": "Find Italian restaurants in Seattle with outdoor seating"
    }
    
    response = requests.post(
        f"{BASE_URL}/invoke",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status: {response.status_code}")
    result = response.json()
    print(f"Response: {json.dumps(result, indent=2)}\n")
    return response.status_code == 200

def test_booking():
    """Test Phase 2: Booking & Payment"""
    print("💳 Testing Booking & Payment (Phase 2)...")
    payload = {
        "correlation_id": "local-test-002",
        "user_id": "test-user-123",
        "session_id": "local-session-002",
        "user_message": "Book a table for 4 people at restaurant ID rest_001 for tomorrow at 7pm"
    }
    
    response = requests.post(
        f"{BASE_URL}/invoke",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status: {response.status_code}")
    result = response.json()
    print(f"Response: {json.dumps(result, indent=2)}\n")
    return response.status_code == 200

def test_history():
    """Test Phase 3: History & Memory"""
    print("📚 Testing History & Memory (Phase 3)...")
    payload = {
        "correlation_id": "local-test-003",
        "user_id": "test-user-123",
        "session_id": "local-session-003",
        "user_message": "Show me my booking history"
    }
    
    response = requests.post(
        f"{BASE_URL}/invoke",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status: {response.status_code}")
    result = response.json()
    print(f"Response: {json.dumps(result, indent=2)}\n")
    return response.status_code == 200

if __name__ == "__main__":
    print("🧪 Testing Local Agent Runtime\n")
    print("Waiting for agent to start...")
    time.sleep(2)
    
    try:
        if test_health():
            test_restaurant_search()
            test_booking()
            test_history()
            print("✅ All tests completed!")
        else:
            print("❌ Health check failed - is the agent running?")
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to localhost:9000")
        print("Run './test-local.sh' first to start the agent")
