# Step-by-Step Deployment Guide
## Restaurant Booking System with Production Principles

This guide walks you through a complete fresh deployment from scratch.

---

## Prerequisites

- [x] AWS CLI configured with credentials
- [x] SAM CLI installed
- [x] Python 3.9+ installed
- [x] jq installed (for JSON parsing)
- [x] AgentCore Gateway ID: `restaurantappgatewayuop91kvy-xg33kutnwg`

---

## Phase 1: Cleanup Existing Infrastructure (15 minutes)

### Step 1.1: Make scripts executable
```bash
chmod +x cleanup-infrastructure.sh
chmod +x setup-fresh-infrastructure.sh
chmod +x register-mcp-tools.sh
```

### Step 1.2: Run cleanup script
```bash
./cleanup-infrastructure.sh
```

**What this does:**
- Unregisters all MCP tools from AgentCore Gateway
- Deletes SAM CloudFormation stack (removes all Lambda functions)
- Deletes all 5 DynamoDB tables
- Verifies cleanup completion

**Expected output:**
```
✅ Cleanup Complete!
  - 0 Lambda functions remaining
  - 0 DynamoDB tables remaining
```

**⏱️ Duration:** ~5 minutes

---

## Phase 2: Create Fresh Infrastructure (20 minutes)

### Step 2.1: Run infrastructure setup script
```bash
./setup-fresh-infrastructure.sh
```

**What this does:**
1. Creates 5 DynamoDB tables:
   - `Restaurants` (with CityIndex, CuisineIndex GSIs)
   - `Users` (with MobileIndex, UsernameIndex GSIs)
   - `Bookings` (with UserBookingsIndex, RestaurantBookingsIndex, DateIndex GSIs)
   - `Payments` (with BookingPaymentIndex, UserPaymentIndex GSIs)
   - `IdempotencyCache` (with TTL enabled) **← NEW**

2. Inserts restaurant data (30 restaurants)

3. Builds SAM application with production code

4. Deploys 8 Lambda functions:
   - `fetchRestaurantDetails-dev` (Timeout: 5s)
   - `fetchRestaurantDetailsById-dev` (Timeout: 3s)
   - `searchUserDetails-dev` (Timeout: 3s)
   - `registerUser-dev` (Timeout: 5s)
   - `tokenAmountCalculation-dev` (Timeout: 2s)
   - `bookATable-dev` (Timeout: 10s)
   - `paymentAPI-dev` (Timeout: 15s)
   - `bookRestaurant-dev` (Timeout: 30s)

5. Collects Lambda ARNs and saves to `lambda-arns.json`

**Expected output:**
```
✅ Infrastructure Setup Complete!
  ✓ 5 DynamoDB tables created
  ✓ Restaurant data inserted
  ✓ 8 Lambda functions deployed
  ✓ Lambda ARNs collected
```

**⏱️ Duration:** ~10 minutes

### Step 2.2: Verify infrastructure
```bash
# Check DynamoDB tables
aws dynamodb list-tables --region us-east-1

# Check Lambda functions
aws lambda list-functions --region us-east-1 \
    --query "Functions[?contains(FunctionName, 'dev')].FunctionName"

# Check IdempotencyCache table
aws dynamodb describe-table --table-name IdempotencyCache --region us-east-1 \
    --query 'Table.{Name:TableName,Status:TableStatus,TTL:TimeToLiveDescription}'

# Verify restaurant data
aws dynamodb scan --table-name Restaurants --limit 5 \
    --query 'Items[*].{ID:restaurantId.S,Name:name.S,City:city.S}'
```

**Expected:**
- 5 tables in ACTIVE status
- 8 Lambda functions deployed
- IdempotencyCache has TTL enabled
- Restaurants table has 30 records

---

## Phase 3: Register MCP Tools (10 minutes)

### Step 3.1: Verify lambda-arns.json
```bash
cat lambda-arns.json
```

**Expected:** JSON file with 8 Lambda ARNs

### Step 3.2: Register tools with AgentCore Gateway
```bash
./register-mcp-tools.sh
```

**What this does:**
- Registers 7 Lambda functions as MCP tools in AgentCore Gateway
- Each tool includes:
  - Function schema with parameters
  - Description and purpose
  - Side-effect classification (READ_ONLY, MUTATING, IRREVERSIBLE)
  - Idempotency requirements

**Expected output:**
```
✅ MCP Tool Registration Complete!
  1. fetchRestaurantDetails ✅
  2. fetchRestaurantDetailsById ✅
  3. searchUserDetails ✅
  4. registerUser ✅
  5. tokenAmountCalculation ✅
  6. bookATable ✅
  7. paymentAPI ✅
```

**⏱️ Duration:** ~3 minutes

### Step 3.3: Verify MCP tool registration
```bash
# List registered tools
aws bedrock-agent list-agent-action-groups \
    --agent-id restaurantappgatewayuop91kvy-xg33kutnwg \
    --region us-east-1 \
    --query 'actionGroupSummaries[*].actionGroupName'
```

**Expected:** 7 action groups listed

---

## Phase 4: Test Deployment (10 minutes)

### Step 4.1: Update test file (already done)
The `test-individual-mcp-tools.py` has been updated with:
- `requestId` parameter for bookATable (REQUIRED)
- `requestId` parameter for paymentAPI (REQUIRED)
- `requestId` parameter for registerUser (OPTIONAL)
- Correct parameter names matching Lambda schemas

### Step 4.2: Run tests
```bash
python test-individual-mcp-tools.py
```

**Expected output:**
```
🧪 Testing fetchRestaurantDetails...
✅ fetchRestaurantDetails - Success
   Found 30 restaurants

🧪 Testing fetchRestaurantDetailsById...
✅ fetchRestaurantDetailsById - Success
   Restaurant: Italian Bistro

🧪 Testing tokenAmountCalculation...
✅ tokenAmountCalculation - Success
   Total Amount: $112.0

🧪 Testing registerUser...
✅ registerUser - Success
   User ID: user_abc123

🧪 Testing searchUserDetails...
✅ searchUserDetails - Success
   Found user: test_user_1234567890

🧪 Testing bookATable...
✅ bookATable - Success
   Booking ID: booking_xyz789

🧪 Testing paymentAPI...
✅ paymentAPI - Success
   Payment Status: completed
```

### Step 4.3: Test idempotency
```bash
# Run the same test twice - should get cached response
python test-individual-mcp-tools.py
python test-individual-mcp-tools.py
```

**Expected:** Second run returns same booking IDs (cached responses)

### Step 4.4: Check IdempotencyCache
```bash
# Verify cache entries
aws dynamodb scan --table-name IdempotencyCache --limit 10 \
    --query 'Items[*].{RequestID:requestId.S,CreatedAt:createdAt.S}'
```

**Expected:** Multiple entries with requestIds from tests

---

## Phase 5: Validation & Monitoring (5 minutes)

### Step 5.1: Check CloudWatch Logs
```bash
# Check bookATable logs
aws logs tail /aws/lambda/bookATable-dev --since 10m --follow

# Check paymentAPI logs
aws logs tail /aws/lambda/paymentAPI-dev --since 10m --follow
```

**Look for:**
- ✅ No ERROR messages
- ✅ Idempotency cache hits
- ✅ Successful tool invocations

### Step 5.2: Test HITL (Human-in-the-Loop)
```bash
# Manually test booking with >10 guests
# Should return 202 with requiresApproval: true
```

Create test file `test-hitl.py`:
```python
import requests
import json

result = requests.post(
    "https://restaurantappgatewayuop91kvy-xg33kutnwg.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp",
    headers={
        "Authorization": "Bearer YOUR_TOKEN",
        "Content-Type": "application/json"
    },
    json={
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "book-a-table-target___bookATable",
            "arguments": {
                "restaurantId": "rest_001",
                "userName": "Large Group",
                "userMobileNo": "+1234567890",
                "date": "2024-12-25",
                "time": "19:00",
                "type": "Dinner",
                "cityName": "NYC",
                "noOfGuests": 15,  # >10 triggers HITL
                "tokenAmount": 500.0,
                "requestId": "test_hitl_123"
            }
        }
    }
)

print(json.dumps(result.json(), indent=2))
```

**Expected:** HTTP 202 with `requiresApproval: true`

### Step 5.3: Test Circuit Breaker
```bash
# Trigger 5 payment failures to open circuit
# 6th attempt should return 503
```

### Step 5.4: Monitor Costs
```bash
# Check DynamoDB usage
aws dynamodb describe-table --table-name IdempotencyCache \
    --query 'Table.{ItemCount:ItemCount,SizeBytes:TableSizeBytes}'

# Check Lambda invocations
aws cloudwatch get-metric-statistics \
    --namespace AWS/Lambda \
    --metric-name Invocations \
    --dimensions Name=FunctionName,Value=bookATable-dev \
    --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
    --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
    --period 3600 \
    --statistics Sum
```

---

## Production Principles Implemented

### ✅ 1. Idempotency (CRITICAL)
- **Implementation:** IdempotencyCache DynamoDB table with 24-hour TTL
- **Functions:** bookATable, paymentAPI, registerUser
- **Test:** Run same request twice, verify cached response

### ✅ 2. Bounded Execution (HIGH)
- **Implementation:** Function-specific timeouts (2s-15s)
- **Test:** Check SAM template and Lambda configurations

### ✅ 3. Deterministic Behavior (HIGH)
- **Implementation:** Hash-based payment simulation
- **Test:** Same requestId produces same payment result

### ✅ 4. Output Size Limits (MEDIUM)
- **Implementation:** Max 50 restaurants per search
- **Test:** Search returns ≤50 results

### ✅ 5. Schema Validation (MEDIUM)
- **Implementation:** Strict input validation with validators
- **Test:** Send invalid inputs, verify 400 errors

### ✅ 6. HITL (MEDIUM)
- **Implementation:** Groups >10 require approval
- **Test:** Book 15 guests, verify 202 response

### ✅ 7. Circuit Breaker (LOW)
- **Implementation:** 5 failures → open for 60s
- **Test:** Trigger 5 failures, verify 503 on 6th

---

## Troubleshooting

### Issue: SAM build fails
```bash
# Check Python version
python3 --version  # Should be 3.9+

# Install dependencies
pip install -r src/lambda/requirements.txt
```

### Issue: DynamoDB table creation fails
```bash
# Check if table already exists
aws dynamodb describe-table --table-name Restaurants

# Delete and retry
aws dynamodb delete-table --table-name Restaurants
```

### Issue: MCP tool registration fails
```bash
# Check Lambda ARN
aws lambda get-function --function-name bookATable-dev

# Verify Gateway ID
aws bedrock-agent get-agent --agent-id restaurantappgatewayuop91kvy-xg33kutnwg
```

### Issue: Tests fail with 400 error
```bash
# Check CloudWatch logs
aws logs tail /aws/lambda/bookATable-dev --since 5m

# Verify requestId is included
# Verify parameter names match schema
```

---

## Rollback Procedure

If deployment fails:

```bash
# 1. Delete IdempotencyCache
aws dynamodb delete-table --table-name IdempotencyCache

# 2. Rollback SAM stack
aws cloudformation delete-stack --stack-name restaurant-booking-dev

# 3. Re-run cleanup
./cleanup-infrastructure.sh

# 4. Start fresh
./setup-fresh-infrastructure.sh
```

---

## Success Criteria

- [x] All 5 DynamoDB tables created and ACTIVE
- [x] All 8 Lambda functions deployed successfully
- [x] All 7 MCP tools registered in AgentCore Gateway
- [x] test-individual-mcp-tools.py passes all tests
- [x] Idempotency works (duplicate requests cached)
- [x] HITL triggers for groups >10
- [x] No errors in CloudWatch logs
- [x] IdempotencyCache has TTL enabled

---

## Timeline Summary

| Phase | Duration | Status |
|-------|----------|--------|
| Cleanup | 5 min | ⏳ |
| Infrastructure Setup | 10 min | ⏳ |
| MCP Registration | 3 min | ⏳ |
| Testing | 10 min | ⏳ |
| Validation | 5 min | ⏳ |
| **Total** | **33 min** | |

---

## Next Steps After Deployment

1. ✅ Update API documentation with requestId requirement
2. ✅ Set up CloudWatch alarms for errors and latency
3. ✅ Configure budget alerts for cost monitoring
4. ✅ Run load tests to validate performance
5. ✅ Update runbooks with operational procedures
6. ✅ Train team on new idempotency requirements

---

**Questions or Issues?**
- Check `DEPLOYMENT_PLAN.md` for detailed information
- Review `IMPLEMENTATION_GAPS_CLOSED.md` for production principles
- Check CloudWatch logs for error details
