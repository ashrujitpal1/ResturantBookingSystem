#!/usr/bin/env python3
"""
Bedrock AgentCore Gateway Setup Script
Creates MCP Gateway with Cognito authentication for Restaurant Booking System APIs
"""

import boto3
import random
import string
import json
import logging
from bedrock_agentcore_starter_toolkit.operations.gateway.client import GatewayClient

def setup_agentcore_gateway():
    """Setup Bedrock AgentCore Gateway for Restaurant Booking System"""
    
    # Core clients and variables
    sts_client = boto3.client('sts')
    account_id = sts_client.get_caller_identity()["Account"]
    region_name = boto3.session.Session().region_name
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    
    print(f"Account: {account_id}, Region: {region_name}, Suffix: {suffix}")
    
    # Setup the GatewayClient
    client = GatewayClient(region_name=region_name)
    client.logger.setLevel(logging.DEBUG)
    
    print("🚀 Creating Cognito OAuth authorizer...")
    # Create cognito authorizer
    cognito_response = client.create_oauth_authorizer_with_cognito("RestaurantBookingAuth")
    
    # Debug: Print the response structure
    print(f"Cognito response keys: {list(cognito_response.keys())}")
    
    # Handle different response structures
    authorizer_name = "RestaurantBookingAuth"
    if 'authorizer_config' in cognito_response:
        if 'authorizerName' in cognito_response['authorizer_config']:
            authorizer_name = cognito_response['authorizer_config']['authorizerName']
    
    print(f"✅ Cognito authorizer created: {authorizer_name}")
    
    print("🚀 Creating MCP Gateway...")
    # Create the gateway with custom name
    gateway = client.create_mcp_gateway(
        name=f"RestaurantAppGateway{suffix}",
        authorizer_config=cognito_response["authorizer_config"]
    )
    
    # Get the gateway ID from the gateway object
    gateway_id = gateway.get('gatewayId') or gateway.get('gatewayArn').split('/')[-1]
    print(f"✅ Gateway ID: {gateway_id}")
    
    # Get the gateway url
    gateway_url = gateway.get('gatewayUrl')
    print(f"✅ Gateway URL: {gateway_url}")
    
    print("🚀 Generating access token...")
    # Get access token
    access_token = client.get_access_token_for_cognito(cognito_response["client_info"])
    print("✅ Access token generated successfully")
    
    # Save configuration to file
    config = {
        "gateway_id": gateway_id,
        "gateway_url": gateway_url,
        "authorizer_config": cognito_response["authorizer_config"],
        "client_info": cognito_response["client_info"],
        "access_token": access_token,
        "account_id": account_id,
        "region": region_name
    }
    
    with open('agentcore-gateway-config.json', 'w') as f:
        json.dump(config, f, indent=2, default=str)
    
    print("✅ Gateway configuration saved to agentcore-gateway-config.json")
    
    return {
        "gateway_id": gateway_id,
        "gateway_url": gateway_url,
        "access_token": access_token,
        "client": client
    }

def register_apis_with_gateway(gateway_config):
    """Register Restaurant Booking APIs with the MCP Gateway"""
    
    print("🚀 Registering APIs with MCP Gateway...")
    
    # Load OpenAPI specification
    with open('openapi-spec.yaml', 'r') as f:
        openapi_spec = f.read()
    
    # TODO: Implement API registration with gateway
    # This will depend on the specific methods available in the GatewayClient
    print("📝 OpenAPI specification loaded - ready for registration")
    print("⚠️  API registration implementation depends on GatewayClient methods")
    
    return True

if __name__ == "__main__":
    try:
        print("🏗️  Setting up Bedrock AgentCore Gateway for Restaurant Booking System")
        print("=" * 70)
        
        # Setup gateway
        gateway_config = setup_agentcore_gateway()
        
        print("\n🔧 Gateway Setup Complete!")
        print("=" * 70)
        print(f"Gateway ID: {gateway_config['gateway_id']}")
        print(f"Gateway URL: {gateway_config['gateway_url']}")
        print("Configuration saved to: agentcore-gateway-config.json")
        
        # Register APIs
        print("\n🔗 Registering APIs...")
        register_apis_with_gateway(gateway_config)
        
        print("\n✅ AgentCore Gateway setup completed successfully!")
        print("Next steps:")
        print("1. Review agentcore-gateway-config.json")
        print("2. Test MCP tool discovery")
        print("3. Validate tool responses")
        
    except Exception as e:
        print(f"❌ Error setting up AgentCore Gateway: {str(e)}")
        raise