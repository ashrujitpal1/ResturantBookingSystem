# Restaurant Booking System - Production Deployment

## 🚀 Quick Start (20 minutes)

```bash
# 1. Cleanup existing infrastructure
./cleanup-infrastructure.sh

# 2. Create fresh infrastructure
./setup-fresh-infrastructure.sh

# 3. Register MCP tools
./register-mcp-tools.sh

# 4. Test deployment
python test-individual-mcp-tools.py
```

---

## 📚 Documentation Index

### Getting Started
- **[EXECUTIVE_SUMMARY.md](EXECUTIVE_SUMMARY.md)** - Overview of changes and deployment approach
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Quick commands and troubleshooting
- **[STEP_BY_STEP_GUIDE.md](STEP_BY_STEP_GUIDE.md)** - Detailed deployment walkthrough

### Technical Documentation
- **[DEPLOYMENT_PLAN.md](DEPLOYMENT_PLAN.md)** - Complete deployment strategy
- **[IMPLEMENTATION_GAPS_CLOSED.md](IMPLEMENTATION_GAPS_CLOSED.md)** - Production principles implementation
- **[application-prod.md](application-prod.md)** - Architecture and design patterns
- **[DynamoDB-Schema.md](DynamoDB-Schema.md)** - Database schema and access patterns

### Scripts
- **[cleanup-infrastructure.sh](cleanup-infrastructure.sh)** - Remove all existing resources
- **[setup-fresh-infrastructure.sh](setup-fresh-infrastructure.sh)** - Create infrastructure from scratch
- **[register-mcp-tools.sh](register-mcp-tools.sh)** - Register Lambda functions as MCP tools

---

## 🎯 What Gets Deployed

### Infrastructure (5 DynamoDB Tables)
- ✅ **Restaurants** - 30 restaurant records with GSIs
- ✅ **Users** - User profiles and preferences
- ✅ **Bookings** - Table reservations
- ✅ **Payments** - Payment transactions
- ✅ **IdempotencyCache** - NEW: Prevents duplicate operations (24h TTL)

### Lambda Functions (8 Functions)
| Function | Timeout | Changes |
|----------|---------|---------|
| fetchRestaurantDetails | 5s | Output limit (50) |
| fetchRestaurantDetailsById | 3s | No changes |
| searchUserDetails | 3s | No changes |
| registerUser | 5s | Optional requestId |
| tokenAmountCalculation | 2s | Validation |
| bookATable | 10s | **REQUIRES requestId** |
| paymentAPI | 15s | **REQUIRES requestId** |
| bookRestaurant | 30s | No changes |

### MCP Tools (7 Tools)
All Lambda functions registered as MCP tools in AgentCore Gateway with proper schemas.

---

## ⚠️ Breaking Changes

### bookATable - NOW REQUIRES requestId
```json
{
  "restaurantId": "rest_001",
  "userName": "John Doe",
  "userMobileNo": "+1234567890",
  "date": "2024-12-25",
  "time": "19:00",
  "type": "Dinner",
  "cityName": "NYC",
  "noOfGuests": 4,
  "tokenAmount": 100.0,
  "requestId": "req_123_booking"  // ← REQUIRED
}
```

### paymentAPI - NOW REQUIRES requestId
```json
{
  "userId": "user_001",
  "restaurantId": "rest_001",
  "bookingId": "booking_123",
  "tokenAmount": 100.0,
  "paymentMethod": "credit_card",
  "requestId": "req_123_payment"  // ← REQUIRED
}
```

**Impact:** Test file already updated with requestId parameters.

---

## 🏆 Production Principles Implemented

| # | Principle | Status | Benefit |
|---|-----------|--------|---------|
| 1 | **Idempotency** | ✅ | Prevents duplicate bookings/payments |
| 2 | **Bounded Execution** | ✅ | Faster failure detection (2s-15s timeouts) |
| 3 | **Deterministic Behavior** | ✅ | Same input → same output |
| 4 | **Output Size Limits** | ✅ | Max 50 results prevents payload issues |
| 5 | **Schema Validation** | ✅ | Strict input validation |
| 6 | **HITL** | ✅ | Groups >10 require manual approval |
| 7 | **Circuit Breaker** | ✅ | Payment resilience (5 failures → open 60s) |

---

## 📊 Deployment Timeline

| Phase | Duration | Script |
|-------|----------|--------|
| Cleanup | 5 min | `./cleanup-infrastructure.sh` |
| Infrastructure | 10 min | `./setup-fresh-infrastructure.sh` |
| MCP Registration | 3 min | `./register-mcp-tools.sh` |
| Testing | 2 min | `python test-individual-mcp-tools.py` |
| **Total** | **20 min** | |

---

## 🔍 Verification

### Check Infrastructure
```bash
# DynamoDB tables
aws dynamodb list-tables --region us-east-1

# Lambda functions
aws lambda list-functions --region us-east-1 \
  --query "Functions[?contains(FunctionName, 'dev')].FunctionName"

# IdempotencyCache
aws dynamodb describe-table --table-name IdempotencyCache \
  --query 'Table.{Status:TableStatus,TTL:TimeToLiveDescription}'

# MCP tools
aws bedrock-agent list-agent-action-groups \
  --agent-id restaurantappgatewayuop91kvy-xg33kutnwg \
  --region us-east-1
```

### Test Idempotency
```bash
# Run tests twice - should get cached responses
python test-individual-mcp-tools.py
python test-individual-mcp-tools.py
```

### Check Logs
```bash
# BookATable logs
aws logs tail /aws/lambda/bookATable-dev --since 10m

# PaymentAPI logs
aws logs tail /aws/lambda/paymentAPI-dev --since 10m

# IdempotencyCache entries
aws dynamodb scan --table-name IdempotencyCache --limit 5
```

---

## 🆘 Troubleshooting

### SAM Build Fails
```bash
pip install -r src/lambda/requirements.txt
sam build --use-container
```

### Table Already Exists
```bash
aws dynamodb delete-table --table-name IdempotencyCache
```

### MCP Registration Fails
```bash
# Verify lambda-arns.json exists
cat lambda-arns.json

# Check Lambda function
aws lambda get-function --function-name bookATable-dev
```

### Tests Fail with 400
```bash
# Check CloudWatch logs
aws logs tail /aws/lambda/bookATable-dev --since 5m

# Verify requestId is included in test
# Verify parameter names match schema
```

---

## 🔄 Rollback

If deployment fails:

```bash
# Quick rollback
./cleanup-infrastructure.sh

# Then redeploy old version
sam deploy --stack-name restaurant-booking-dev
```

---

## 📖 Additional Resources

### Architecture
- [application-prod.md](application-prod.md) - Complete architecture documentation
- [DynamoDB-Schema.md](DynamoDB-Schema.md) - Database design

### Implementation
- [IMPLEMENTATION_GAPS_CLOSED.md](IMPLEMENTATION_GAPS_CLOSED.md) - Production principles details
- [.amazonq/rules/project-rules.md](.amazonq/rules/project-rules.md) - Code generation rules

### Configuration
- [template.yaml](template.yaml) - SAM template with all resources
- [agentcore-gateway-config.json](agentcore-gateway-config.json) - Gateway configuration

---

## ✅ Success Criteria

- [x] All 5 DynamoDB tables created and ACTIVE
- [x] All 8 Lambda functions deployed successfully
- [x] All 7 MCP tools registered in AgentCore Gateway
- [x] test-individual-mcp-tools.py passes all tests
- [x] Idempotency works (duplicate requests cached)
- [x] HITL triggers for groups >10
- [x] No errors in CloudWatch logs
- [x] IdempotencyCache has TTL enabled

---

## 💰 Cost Estimate

### Monthly Costs (Dev Environment)
- **DynamoDB:** ~$1.00 (PAY_PER_REQUEST, low usage)
- **Lambda:** ~$2.00 (minimal invocations)
- **CloudWatch Logs:** ~$0.50 (30-day retention)
- **IdempotencyCache:** ~$0.25 (NEW, minimal usage)

**Total:** ~$3.75/month

---

## 🎓 Learning Resources

### Production Principles
1. **Idempotency** - [IMPLEMENTATION_GAPS_CLOSED.md](IMPLEMENTATION_GAPS_CLOSED.md#1-idempotency-critical)
2. **Circuit Breakers** - [application-prod.md](application-prod.md#circuit-breaker-implementation)
3. **SAGA Pattern** - [application-prod.md](application-prod.md#saga-pattern-for-transactions)
4. **SOLID Principles** - [.amazonq/rules/project-rules.md](.amazonq/rules/project-rules.md#solid-principles-mandatory)

---

## 📞 Support

**Questions?**
1. Check [QUICK_REFERENCE.md](QUICK_REFERENCE.md) for common issues
2. Review [STEP_BY_STEP_GUIDE.md](STEP_BY_STEP_GUIDE.md) for detailed steps
3. Check CloudWatch logs for error details
4. Review [DEPLOYMENT_PLAN.md](DEPLOYMENT_PLAN.md) for troubleshooting

---

## 🚦 Status

- **Version:** 1.0.0
- **Status:** ✅ Ready for Deployment
- **Last Updated:** 2024
- **Environment:** Development

---

**Ready to deploy? Start with [STEP_BY_STEP_GUIDE.md](STEP_BY_STEP_GUIDE.md)**
