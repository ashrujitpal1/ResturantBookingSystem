# Quick Reference Card - Fresh Deployment

## 🚀 Complete Fresh Deployment (3 Commands)

```bash
# 1. Cleanup (5 min)
./cleanup-infrastructure.sh

# 2. Setup Infrastructure (10 min)
./setup-fresh-infrastructure.sh

# 3. Register MCP Tools (3 min)
./register-mcp-tools.sh

# 4. Test (2 min)
python test-individual-mcp-tools.py
```

**Total Time: ~20 minutes**

---

## 📋 What Gets Created

### DynamoDB Tables (5)
- ✅ Restaurants (30 records)
- ✅ Users
- ✅ Bookings
- ✅ Payments
- ✅ IdempotencyCache (NEW - with TTL)

### Lambda Functions (8)
- ✅ fetchRestaurantDetails-dev (5s timeout)
- ✅ fetchRestaurantDetailsById-dev (3s timeout)
- ✅ searchUserDetails-dev (3s timeout)
- ✅ registerUser-dev (5s timeout)
- ✅ tokenAmountCalculation-dev (2s timeout)
- ✅ bookATable-dev (10s timeout) **← REQUIRES requestId**
- ✅ paymentAPI-dev (15s timeout) **← REQUIRES requestId**
- ✅ bookRestaurant-dev (30s timeout)

### MCP Tools (7)
- ✅ fetch-restaurant-details-target
- ✅ fetch-restaurant-by-id-target
- ✅ search-user-details-target
- ✅ register-user-target
- ✅ token-amount-calculation-target
- ✅ book-a-table-target **← REQUIRES requestId**
- ✅ payment-api-target **← REQUIRES requestId**

---

## ⚠️ Breaking Changes

### bookATable
**BEFORE:**
```json
{
  "restaurantId": "rest_001",
  "userName": "John",
  "noOfGuests": 4
}
```

**AFTER:**
```json
{
  "restaurantId": "rest_001",
  "userName": "John",
  "noOfGuests": 4,
  "requestId": "req_123_booking"  // REQUIRED
}
```

### paymentAPI
**BEFORE:**
```json
{
  "userId": "user_001",
  "tokenAmount": 100.0
}
```

**AFTER:**
```json
{
  "userId": "user_001",
  "tokenAmount": 100.0,
  "requestId": "req_123_payment"  // REQUIRED
}
```

---

## 🧪 Quick Tests

### Test Idempotency
```bash
# Run twice with same requestId
python test-individual-mcp-tools.py
python test-individual-mcp-tools.py
# Should return cached responses
```

### Test HITL
```python
# Book with 15 guests
{
  "noOfGuests": 15,  # >10 triggers HITL
  "requestId": "test_hitl"
}
# Expected: HTTP 202 with requiresApproval: true
```

### Test Circuit Breaker
```bash
# Trigger 5 payment failures
# 6th attempt should return 503
```

---

## 🔍 Verification Commands

```bash
# Check tables
aws dynamodb list-tables --region us-east-1

# Check Lambda functions
aws lambda list-functions --region us-east-1 \
  --query "Functions[?contains(FunctionName, 'dev')].FunctionName"

# Check IdempotencyCache
aws dynamodb describe-table --table-name IdempotencyCache \
  --query 'Table.{Status:TableStatus,TTL:TimeToLiveDescription}'

# Check MCP tools
aws bedrock-agent list-agent-action-groups \
  --agent-id restaurantappgatewayuop91kvy-xg33kutnwg \
  --region us-east-1

# Check logs
aws logs tail /aws/lambda/bookATable-dev --since 10m

# Check cache entries
aws dynamodb scan --table-name IdempotencyCache --limit 5
```

---

## 🆘 Troubleshooting

### SAM build fails
```bash
pip install -r src/lambda/requirements.txt
sam build --use-container
```

### Table already exists
```bash
aws dynamodb delete-table --table-name IdempotencyCache
```

### MCP registration fails
```bash
# Check lambda-arns.json exists
cat lambda-arns.json

# Verify Lambda ARN
aws lambda get-function --function-name bookATable-dev
```

### Test fails with 400
```bash
# Check CloudWatch logs
aws logs tail /aws/lambda/bookATable-dev --since 5m

# Verify requestId included
# Verify parameter names match
```

---

## 📊 Production Principles Status

| Principle | Status | Test |
|-----------|--------|------|
| Idempotency | ✅ | Duplicate requests cached |
| Bounded Execution | ✅ | Timeouts 2s-15s |
| Deterministic | ✅ | Same input → same output |
| Output Limits | ✅ | Max 50 results |
| Schema Validation | ✅ | Invalid inputs rejected |
| HITL | ✅ | Groups >10 need approval |
| Circuit Breaker | ✅ | 5 failures → open 60s |

---

## 📖 Documentation Files

- `STEP_BY_STEP_GUIDE.md` - Detailed deployment guide
- `DEPLOYMENT_PLAN.md` - Complete deployment plan
- `IMPLEMENTATION_GAPS_CLOSED.md` - Production principles
- `application-prod.md` - Architecture documentation
- `DynamoDB-Schema.md` - Database schema

---

## 🎯 Success Criteria

- [x] 5 tables ACTIVE
- [x] 8 Lambda functions deployed
- [x] 7 MCP tools registered
- [x] All tests pass
- [x] Idempotency works
- [x] HITL triggers
- [x] No CloudWatch errors

---

## 📞 Support

**Issues?**
1. Check CloudWatch logs
2. Review STEP_BY_STEP_GUIDE.md
3. Run cleanup and retry
4. Check AWS service quotas

**Cost Monitoring:**
```bash
# Check DynamoDB usage
aws dynamodb describe-table --table-name IdempotencyCache \
  --query 'Table.{Items:ItemCount,Size:TableSizeBytes}'

# Check Lambda invocations
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name Invocations \
  --dimensions Name=FunctionName,Value=bookATable-dev \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 3600 \
  --statistics Sum
```
