# Production Principles Implementation - Deployment Plan

## Current State Analysis

### ✅ Already Deployed
- 8 Lambda functions deployed via SAM
- 4 DynamoDB tables created (Restaurants, Users, Bookings, Payments)
- Restaurant records inserted
- Lambda functions registered as MCP tools in AgentCore Gateway

### ❌ Missing Infrastructure
- **IdempotencyCache** DynamoDB table (CRITICAL)
- Updated Lambda code with production principles
- Lambda layer with shared utilities (utils.py, circuit_breaker.py)

---

## Required Changes Summary

### 1. Infrastructure Changes (AWS)
| Resource | Action | Priority |
|----------|--------|----------|
| IdempotencyCache Table | CREATE | CRITICAL |
| Lambda Functions | UPDATE CODE | CRITICAL |
| Lambda Layer | CREATE | HIGH |
| SAM Template | UPDATE | HIGH |

### 2. Code Changes
| File | Status | Breaking Change |
|------|--------|-----------------|
| utils.py | NEW | N/A |
| circuit_breaker.py | NEW | N/A |
| book_a_table.py | MODIFIED | YES - requires requestId |
| payment_api.py | MODIFIED | YES - requires requestId |
| register_user.py | MODIFIED | NO - requestId optional |
| token_amount_calculation.py | MODIFIED | NO |
| fetch_restaurant_details.py | MODIFIED | NO |

### 3. Test File Changes
| File | Action |
|------|--------|
| test-individual-mcp-tools.py | UPDATE - add requestId |

---

## Deployment Steps

### STEP 1: Create IdempotencyCache Table (5 minutes)
```bash
aws dynamodb create-table \
    --table-name IdempotencyCache \
    --attribute-definitions AttributeName=requestId,AttributeType=S \
    --key-schema AttributeName=requestId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --region us-east-1

# Enable TTL
aws dynamodb update-time-to-live \
    --table-name IdempotencyCache \
    --time-to-live-specification "Enabled=true, AttributeName=ttl" \
    --region us-east-1
```

**Verification:**
```bash
aws dynamodb describe-table --table-name IdempotencyCache --region us-east-1
```

---

### STEP 2: Update SAM Template (Already Done)
The template.yaml has been updated with:
- IdempotencyTable resource
- Function-specific timeouts
- IDEMPOTENCY_TABLE environment variable
- Proper IAM permissions

**No action needed - already updated**

---

### STEP 3: Deploy Updated Lambda Functions (10 minutes)
```bash
# Build SAM application
sam build

# Deploy with existing stack
sam deploy \
    --stack-name restaurant-booking-dev \
    --parameter-overrides Environment=dev \
    --capabilities CAPABILITY_IAM \
    --region us-east-1 \
    --no-confirm-changeset
```

**What gets updated:**
- All 8 Lambda functions with new code
- Lambda timeouts adjusted per spec
- Environment variables added (IDEMPOTENCY_TABLE)
- IAM permissions for IdempotencyCache access

---

### STEP 4: Update Test File (2 minutes)
Update `test-individual-mcp-tools.py` to include requestId for:
- bookATable
- paymentAPI
- registerUser (optional but recommended)

See detailed changes in Section 5 below.

---

### STEP 5: Verify Deployment (5 minutes)
```bash
# Test idempotency
python test-individual-mcp-tools.py

# Check CloudWatch logs
aws logs tail /aws/lambda/bookATable-dev --follow

# Verify IdempotencyCache has entries
aws dynamodb scan --table-name IdempotencyCache --limit 5
```

---

## Detailed Code Changes

### Lambda Functions - Breaking Changes

#### 1. bookATable-dev
**Breaking Change:** Now REQUIRES `requestId` parameter

**Before:**
```json
{
  "restaurantId": "rest_001",
  "userName": "John",
  "userMobileNo": "+1234567890",
  "date": "2024-01-15",
  "time": "19:00",
  "type": "Dinner",
  "cityName": "NYC",
  "noOfGuests": 4,
  "tokenAmount": 100.0
}
```

**After:**
```json
{
  "restaurantId": "rest_001",
  "userName": "John",
  "userMobileNo": "+1234567890",
  "date": "2024-01-15",
  "time": "19:00",
  "type": "Dinner",
  "cityName": "NYC",
  "noOfGuests": 4,
  "tokenAmount": 100.0,
  "requestId": "req_12345_booking_1"  // REQUIRED
}
```

**New Behaviors:**
- Returns 400 if requestId missing
- Returns cached response for duplicate requestId
- Returns 202 for groups >10 (HITL approval required)
- Validates all inputs with strict schema

---

#### 2. paymentAPI-dev
**Breaking Change:** Now REQUIRES `requestId` parameter

**Before:**
```json
{
  "userId": "user_001",
  "restaurantId": "rest_001",
  "bookingId": "booking_123",
  "tokenAmount": 100.0,
  "paymentMethod": "credit_card"
}
```

**After:**
```json
{
  "userId": "user_001",
  "restaurantId": "rest_001",
  "bookingId": "booking_123",
  "tokenAmount": 100.0,
  "paymentMethod": "credit_card",
  "requestId": "req_12345_payment_1"  // REQUIRED
}
```

**New Behaviors:**
- Returns 400 if requestId missing
- Returns cached response for duplicate requestId
- Returns 503 if circuit breaker is open
- Deterministic payment simulation (same requestId = same result)

---

#### 3. registerUser-dev
**Non-Breaking Change:** `requestId` is OPTIONAL

**After:**
```json
{
  "username": "john_doe",
  "mobileNo": "+1234567890",
  "userCity": "NYC",
  "userPreference": {},
  "requestId": "req_12345_register_1"  // OPTIONAL
}
```

**New Behaviors:**
- If requestId provided, uses idempotency cache
- Validates phone number format
- Returns 409 if mobile number already exists

---

### Lambda Functions - Non-Breaking Changes

#### 4. tokenAmountCalculation-dev
- Added strict input validation (noOfGuests 1-20)
- No schema changes

#### 5. fetchRestaurantDetails-dev
- Added output size limit (max 50 results)
- No schema changes

#### 6. fetchRestaurantDetailsById-dev
- No changes

#### 7. searchUserDetails-dev
- No changes

#### 8. bookRestaurant-dev
- No changes (if this function exists)

---

## Test File Updates

### test-individual-mcp-tools.py Changes

```python
import time

# Generate unique requestId helper
def generate_request_id(operation):
    return f"test_{int(time.time())}_{operation}"

# UPDATE: test_book_table function
def test_book_table(gateway_url, access_token, user_id):
    """Test bookATable tool"""
    
    print("\n🧪 Testing bookATable...")
    
    result = call_mcp_tool(
        gateway_url,
        access_token,
        "book-a-table-target___bookATable",
        {
            "restaurantId": "rest_001",
            "userName": "Test User",
            "userMobileNo": "+1234567890",
            "date": "2024-12-25",
            "time": "19:00",
            "type": "Dinner",
            "cityName": "New York",
            "noOfGuests": 4,
            "tokenAmount": 100.0,
            "requestId": generate_request_id("booking")  # ADD THIS
        }
    )
    
    if "error" not in result:
        print("✅ bookATable - Success")
        if "result" in result and "content" in result["result"]:
            content = result["result"]["content"]
            if isinstance(content, list) and len(content) > 0:
                booking = json.loads(content[0]["text"])
                booking_id = booking.get('bookingId')
                print(f"   Booking ID: {booking_id}")
                return booking_id
        return True
    else:
        print(f"❌ bookATable - Failed: {result['error']}")
        return None

# UPDATE: test_payment function
def test_payment(gateway_url, access_token, booking_id, user_id):
    """Test paymentAPI tool"""
    
    print("\n🧪 Testing paymentAPI...")
    
    result = call_mcp_tool(
        gateway_url,
        access_token,
        "payment-api-target___paymentAPI",
        {
            "userId": user_id,
            "restaurantId": "rest_001",
            "bookingId": booking_id,
            "tokenAmount": 100.0,
            "paymentMethod": "credit_card",
            "requestId": generate_request_id("payment")  # ADD THIS
        }
    )
    
    if "error" not in result:
        print("✅ paymentAPI - Success")
        if "result" in result and "content" in result["result"]:
            content = result["result"]["content"]
            if isinstance(content, list) and len(content) > 0:
                payment = json.loads(content[0]["text"])
                print(f"   Payment Status: {payment.get('paymentStatus', 'Unknown')}")
        return True
    else:
        print(f"❌ paymentAPI - Failed: {result['error']}")
        return False

# UPDATE: test_register_user function (optional but recommended)
def test_register_user(gateway_url, access_token):
    """Test registerUser tool"""
    
    print("\n🧪 Testing registerUser...")
    
    result = call_mcp_tool(
        gateway_url,
        access_token,
        "register-user-target___registerUser",
        {
            "username": f"test_user_{int(time.time())}",
            "mobileNo": "+1234567890",
            "userCity": "New York",
            "userPreference": {"cuisine": ["Italian"]},
            "requestId": generate_request_id("register")  # ADD THIS
        }
    )
    
    if "error" not in result:
        print("✅ registerUser - Success")
        if "result" in result and "content" in result["result"]:
            content = result["result"]["content"]
            if isinstance(content, list) and len(content) > 0:
                user_result = json.loads(content[0]["text"])
                user_id = user_result.get('userId')
                print(f"   User ID: {user_id}")
                return user_id
        return True
    else:
        print(f"❌ registerUser - Failed: {result['error']}")
        return None
```

---

## Rollback Plan

If deployment fails or causes issues:

### Quick Rollback (5 minutes)
```bash
# Revert to previous Lambda code
aws lambda update-function-code \
    --function-name bookATable-dev \
    --s3-bucket <previous-bucket> \
    --s3-key <previous-key>

# Repeat for other functions
```

### Full Rollback (10 minutes)
```bash
# Delete IdempotencyCache table
aws dynamodb delete-table --table-name IdempotencyCache

# Rollback SAM stack
sam deploy --stack-name restaurant-booking-dev --no-execute-changeset
# Then manually revert to previous changeset
```

---

## Post-Deployment Validation

### 1. Test Idempotency
```bash
# Call bookATable twice with same requestId
# Should return same response
```

### 2. Test HITL
```bash
# Book table with 15 guests
# Should return 202 with requiresApproval: true
```

### 3. Test Circuit Breaker
```bash
# Trigger 5 payment failures
# 6th attempt should return 503 (circuit open)
```

### 4. Test Deterministic Behavior
```bash
# Call paymentAPI twice with same requestId
# Should return identical results
```

### 5. Monitor CloudWatch
```bash
# Check for errors
aws logs tail /aws/lambda/bookATable-dev --since 5m

# Check IdempotencyCache usage
aws dynamodb describe-table --table-name IdempotencyCache \
    --query 'Table.ItemCount'
```

---

## Timeline

| Step | Duration | Can Run in Parallel |
|------|----------|---------------------|
| Create IdempotencyCache | 5 min | No |
| SAM Build | 3 min | No |
| SAM Deploy | 7 min | No |
| Update Test File | 2 min | Yes |
| Verification | 5 min | No |
| **Total** | **22 min** | |

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Breaking change impacts existing clients | HIGH | HIGH | Update test file first, communicate schema changes |
| IdempotencyCache costs | LOW | LOW | PAY_PER_REQUEST with TTL cleanup |
| Lambda timeout issues | LOW | MEDIUM | Timeouts are conservative (2s-15s) |
| Circuit breaker false positives | LOW | MEDIUM | Threshold set to 5 failures |

---

## Success Criteria

✅ All 8 Lambda functions deployed successfully  
✅ IdempotencyCache table created with TTL enabled  
✅ test-individual-mcp-tools.py passes all tests  
✅ Duplicate requestId returns cached response  
✅ Groups >10 trigger HITL approval  
✅ Circuit breaker opens after 5 failures  
✅ No errors in CloudWatch logs  
✅ Cost per request < $0.01  

---

## Next Steps After Deployment

1. Update MCP tool descriptions in AgentCore Gateway (if needed)
2. Update API documentation with new requestId requirement
3. Notify any existing clients about breaking changes
4. Monitor CloudWatch metrics for 24 hours
5. Run load tests to validate performance
6. Update runbooks with new operational procedures
