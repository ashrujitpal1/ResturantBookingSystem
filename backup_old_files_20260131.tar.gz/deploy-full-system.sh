#!/bin/bash
# Complete Production Deployment - All 3 Phases + Memory
# This script deploys the FULL agentic system with all production patterns

set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🚀 Restaurant Booking System - Complete Production Deployment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "This deploys:"
echo "  ✅ Phase 1: Restaurant Discovery (Search)"
echo "  ✅ Phase 2: Booking & Payment (SAGA pattern)"
echo "  ✅ Phase 3: Memory & History (PII scrubbing)"
echo "  ✅ 5 Production Patterns (85% production ready)"
echo ""

REGION="us-east-1"
AGENT_NAME="restaurant_discovery_agent"
PROMPT_BUCKET="restaurant-booking-prompts"
MEMORY_NAME="restaurant-booking-memory"

# Step 1: Deploy Infrastructure (Lambda + DynamoDB)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📦 Step 1/5: Deploying Backend Infrastructure"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "deploy-production.sh" ]; then
    echo "Running deploy-production.sh..."
    ./deploy-production.sh
else
    echo "⚠️  deploy-production.sh not found, skipping infrastructure"
fi

# Step 2: Create Memory Store
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧠 Step 2/5: Creating Memory Store"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if memory already exists
EXISTING_MEMORY=$(aws bedrock-agentcore list-memories --region $REGION 2>/dev/null | \
    jq -r ".memories[] | select(.memoryName==\"$MEMORY_NAME\") | .memoryId" || echo "")

if [ -n "$EXISTING_MEMORY" ]; then
    echo "✅ Memory store already exists: $EXISTING_MEMORY"
    MEMORY_ID=$EXISTING_MEMORY
    MEMORY_ARN="arn:aws:bedrock-agentcore:$REGION:$(aws sts get-caller-identity --query Account --output text):memory/$MEMORY_ID"
else
    echo "Creating new memory store: $MEMORY_NAME..."
    
    MEMORY_OUTPUT=$(aws bedrock-agentcore create-memory \
        --memory-name $MEMORY_NAME \
        --retention-days 30 \
        --region $REGION \
        --output json 2>/dev/null || echo "{}")
    
    MEMORY_ID=$(echo $MEMORY_OUTPUT | jq -r '.memoryId // empty')
    MEMORY_ARN=$(echo $MEMORY_OUTPUT | jq -r '.memoryArn // empty')
    
    if [ -n "$MEMORY_ID" ]; then
        echo "✅ Memory store created:"
        echo "   Memory ID: $MEMORY_ID"
        echo "   Memory ARN: $MEMORY_ARN"
    else
        echo "⚠️  Failed to create memory store (may need manual creation)"
        MEMORY_ID=""
        MEMORY_ARN=""
    fi
fi

# Step 3: Upload Prompts to S3
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Step 3/5: Uploading Versioned Prompts to S3"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "upload_prompts_to_s3.py" ]; then
    python3 upload_prompts_to_s3.py
    if [ $? -eq 0 ]; then
        echo "✅ Prompts uploaded to s3://$PROMPT_BUCKET/"
    else
        echo "⚠️  Prompt upload failed (will use embedded defaults)"
    fi
else
    echo "⚠️  upload_prompts_to_s3.py not found, skipping"
fi

# Step 4: Update Configuration
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📝 Step 4/5: Updating Agent Configuration"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Backup current config
cp .bedrock_agentcore.yaml .bedrock_agentcore.yaml.backup

# Update entrypoint to complete_booking_workflow.py
echo "Updating entrypoint to complete_booking_workflow.py..."
sed -i.tmp 's|entrypoint: .*/restaurant_workflow.py|entrypoint: /Users/USER/Work/AI/AgentCore/ResturantBookingSystem/restaurant_agent_runtime/complete_booking_workflow.py|' .bedrock_agentcore.yaml

# Update memory configuration if memory was created
if [ -n "$MEMORY_ID" ]; then
    echo "Enabling memory with ID: $MEMORY_ID..."
    
    # Use Python to update YAML properly
    python3 << EOF
import yaml

with open('.bedrock_agentcore.yaml', 'r') as f:
    config = yaml.safe_load(f)

# Update memory config for default agent
default_agent = config.get('default_agent')
if default_agent and default_agent in config.get('agents', {}):
    config['agents'][default_agent]['memory'] = {
        'mode': 'MEMORY_ENABLED',
        'memory_id': '$MEMORY_ID',
        'memory_arn': '$MEMORY_ARN',
        'memory_name': '$MEMORY_NAME',
        'event_expiry_days': 30,
        'first_invoke_memory_check_done': False,
        'was_created_by_toolkit': True
    }

with open('.bedrock_agentcore.yaml', 'w') as f:
    yaml.dump(config, f, default_flow_style=False, sort_keys=False)

print("✅ Memory configuration updated")
EOF
else
    echo "⚠️  Memory not configured (will run without memory)"
fi

# Set environment variables
echo "Setting environment variables..."
export MEMORY_ID=$MEMORY_ID
export PROMPT_BUCKET=$PROMPT_BUCKET
export PROMPT_VERSION="1.0.0"

echo "✅ Configuration updated"
echo "   Entrypoint: complete_booking_workflow.py"
echo "   Memory: ${MEMORY_ID:-Not configured}"

# Step 5: Deploy to AgentCore
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🚀 Step 5/5: Deploying to AgentCore Runtime"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "This may take 5-10 minutes..."
echo ""

read -p "Proceed with deployment? (y/n): " proceed

if [ "$proceed" != "y" ]; then
    echo "❌ Deployment cancelled"
    exit 0
fi

bedrock-agentcore deploy --agent-name $AGENT_NAME

# Deployment Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ DEPLOYMENT COMPLETE!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📦 Deployed Components:"
echo "   ✅ Phase 1: Restaurant Discovery (Search)"
echo "   ✅ Phase 2: Booking & Payment (SAGA pattern)"
echo "   ✅ Phase 3: Memory & History (PII scrubbing)"
echo ""
echo "🎯 Production Patterns (5/10):"
echo "   ✅ Model Selection & Cost Optimization (43.75% reduction)"
echo "   ✅ Prompt Versioning (S3 + LRU caching)"
echo "   ✅ LLM Provider Abstraction (SOLID + fallback)"
echo "   ✅ Prompt Injection Defense (8 patterns)"
echo "   ✅ Governance Policies (max limits + HITL)"
echo ""
echo "🔧 Configuration:"
echo "   Agent: $AGENT_NAME"
echo "   Region: $REGION"
echo "   Memory: ${MEMORY_ID:-Not configured}"
echo "   Prompts: s3://$PROMPT_BUCKET/"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧪 Testing Your Deployment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Run tests:"
echo "  python3 test_deployed_agent.py"
echo ""
echo "Test scenarios:"
echo "  1. Search: 'Find Italian restaurants in New York'"
echo "  2. Booking: 'Book a table for 4 people tomorrow at 7pm'"
echo "  3. Memory: 'Show me my booking history'"
echo "  4. HITL: 'Book for 15 people' (requires approval)"
echo ""
echo "View logs:"
echo "  aws logs tail /aws/bedrock-agentcore/$AGENT_NAME --follow"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📋 Environment Variables (add to ~/.bashrc or ~/.zshrc)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "export MEMORY_ID=\"$MEMORY_ID\""
echo "export PROMPT_BUCKET=\"$PROMPT_BUCKET\""
echo "export PROMPT_VERSION=\"1.0.0\""
echo ""
echo "✨ Deployment successful! Your production-ready agent is live!"
echo ""
