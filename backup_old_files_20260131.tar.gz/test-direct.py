#!/usr/bin/env python3
"""Direct test of workflow without HTTP server"""
import sys
sys.path.insert(0, '/Users/USER/Work/AI/AgentCore/ResturantBookingSystem')

from restaurant_agent_runtime.complete_booking_workflow import invoke

# Test 1: Restaurant Search
print("🔍 Test 1: Restaurant Search")
result1 = invoke({
    "prompt": "Find Italian restaurants in Seattle",
    "user_id": "test-user-123",
    "session_id": "test-session-001"
})
print(f"Result: {result1.get('final_response', 'No response')}\n")

# Test 2: Booking
print("💳 Test 2: Booking")
result2 = invoke({
    "prompt": "Book a table for 4 people tomorrow at 7pm",
    "user_id": "test-user-123",
    "session_id": "test-session-002"
})
print(f"Result: {result2.get('final_response', 'No response')}\n")

print("✅ Direct workflow tests completed!")
