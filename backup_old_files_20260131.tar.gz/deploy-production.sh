#!/bin/bash
# Quick deployment script for production principles implementation

set -e

echo "🚀 Deploying Production-Grade Restaurant Booking System"
echo "========================================================="
echo ""

# Step 1: Create IdempotencyCache table
echo "📦 Step 1/3: Creating IdempotencyCache table..."
aws dynamodb create-table \
    --table-name IdempotencyCache \
    --attribute-definitions AttributeName=requestId,AttributeType=S \
    --key-schema AttributeName=requestId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --region us-east-1 \
    --no-cli-pager 2>/dev/null && echo "✅ Table created" || echo "⚠️  Table already exists"

echo ""
echo "⏰ Enabling TTL on IdempotencyCache..."
aws dynamodb update-time-to-live \
    --table-name IdempotencyCache \
    --time-to-live-specification "Enabled=true, AttributeName=ttl" \
    --region us-east-1 \
    --no-cli-pager 2>/dev/null && echo "✅ TTL enabled" || echo "⚠️  TTL already enabled"

# Step 2: Build and deploy Lambda functions
echo ""
echo "🔨 Step 2/3: Building SAM application..."
sam build

echo ""
echo "📤 Deploying Lambda functions..."
sam deploy \
    --stack-name restaurant-booking-dev \
    --parameter-overrides Environment=dev \
    --capabilities CAPABILITY_IAM \
    --region us-east-1 \
    --resolve-s3 \
    --no-confirm-changeset \
    --no-fail-on-empty-changeset

# Step 3: Verify deployment
echo ""
echo "✅ Step 3/3: Verifying deployment..."

echo ""
echo "Checking IdempotencyCache table..."
aws dynamodb describe-table --table-name IdempotencyCache --region us-east-1 --query 'Table.TableStatus' --output text

echo ""
echo "Checking Lambda functions..."
for func in bookATable-dev paymentAPI-dev registerUser-dev tokenAmountCalculation-dev; do
    status=$(aws lambda get-function --function-name $func --region us-east-1 --query 'Configuration.LastUpdateStatus' --output text 2>/dev/null || echo "NOT_FOUND")
    echo "  $func: $status"
done

echo ""
echo "========================================================="
echo "✅ Deployment Complete!"
echo ""
echo "📋 Next Steps:"
echo "  1. Update test file: test-individual-mcp-tools.py (already done)"
echo "  2. Run tests: python test-individual-mcp-tools.py"
echo "  3. Monitor CloudWatch logs for any errors"
echo ""
echo "⚠️  BREAKING CHANGES:"
echo "  - bookATable now REQUIRES 'requestId' parameter"
echo "  - paymentAPI now REQUIRES 'requestId' parameter"
echo "  - registerUser accepts optional 'requestId' parameter"
echo ""
echo "📖 See DEPLOYMENT_PLAN.md for detailed information"
