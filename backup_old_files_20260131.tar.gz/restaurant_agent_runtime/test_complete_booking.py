#!/usr/bin/env python3
"""
Test Complete Restaurant Booking System
Phase 1: Restaurant Discovery + Phase 2: Booking & Payment
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from complete_booking_workflow import invoke

def test_restaurant_search():
    """Test Phase 1: Restaurant Search"""
    print("=" * 80)
    print("TEST 1: Restaurant Search (Phase 1)")
    print("=" * 80)
    
    payload = {
        "prompt": "Find Italian restaurants in New York",
        "user_id": "test_user_001",
        "session_id": "test_session_001",
        "search_params": {"city": "New York", "cuisine": "Italian"}
    }
    
    result = invoke(payload)
    print(f"\n✅ Status: {result.get('status')}")
    print(f"📍 Intent: {result.get('intent')}")
    print(f"🍽️ Restaurants: {len(result.get('restaurant_results', []))}")
    print(f"\n📝 Response:\n{result.get('final_response')}")
    print("\n" + "=" * 80)

def test_complete_booking():
    """Test Phase 2: Complete Booking Flow"""
    print("\nTEST 2: Complete Booking Flow (Phase 1 + Phase 2)")
    print("=" * 80)
    
    payload = {
        "prompt": "Book a table for 2 at an Italian restaurant tomorrow at 7pm",
        "user_id": "test_user_002",
        "session_id": "test_session_002",
        "search_params": {"city": "New York", "cuisine": "Italian"},
        "booking_details": {
            "date": "2024-02-15",
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 2,
            "user_mobile": "+15551234567",
            "user_name": "John Doe"
        }
    }
    
    result = invoke(payload)
    print(f"\n✅ Status: {result.get('status')}")
    print(f"📍 Intent: {result.get('intent')}")
    print(f"🍽️ Restaurants Found: {len(result.get('restaurant_results', []))}")
    
    booking = result.get('booking_result', {})
    if booking:
        print(f"\n📋 Booking Details:")
        print(f"   Booking ID: {booking.get('bookingId')}")
        print(f"   Reference: {booking.get('bookingReference')}")
        print(f"   Restaurant: {booking.get('restaurantId')}")
        print(f"   Guests: {booking.get('noOfGuests')}")
    
    payment = result.get('payment_result', {})
    if payment:
        print(f"\n💳 Payment Details:")
        print(f"   Payment ID: {payment.get('paymentId')}")
        print(f"   Status: {payment.get('paymentStatus')}")
        print(f"   Amount: ${payment.get('amount')}")
    
    print(f"\n📝 Final Response:\n{result.get('final_response')}")
    print(f"\n💾 Memory: {result.get('memory_status')}")
    print("\n" + "=" * 80)

def test_user_registration():
    """Test User Management"""
    print("\nTEST 3: User Registration & Management")
    print("=" * 80)
    
    payload = {
        "prompt": "Book a table for 4 people",
        "user_id": "new_user_003",
        "session_id": "test_session_003",
        "search_params": {},
        "booking_details": {
            "date": "2024-02-20",
            "time": "18:30",
            "meal_type": "Dinner",
            "no_of_guests": 4,
            "user_mobile": "+15559876543",
            "user_name": "Jane Smith"
        }
    }
    
    result = invoke(payload)
    print(f"\n✅ Status: {result.get('status')}")
    print(f"📝 Response:\n{result.get('final_response')}")
    print("\n" + "=" * 80)

def test_history_retrieval():
    """Test Memory Retrieval"""
    print("\nTEST 4: History Retrieval")
    print("=" * 80)
    
    payload = {
        "prompt": "Show me my booking history",
        "user_id": "test_user_001",
        "session_id": "test_session_001"
    }
    
    result = invoke(payload)
    print(f"\n✅ Status: {result.get('status')}")
    print(f"📍 Intent: {result.get('intent')}")
    print(f"\n📝 Response:\n{result.get('final_response')}")
    print("\n" + "=" * 80)

if __name__ == "__main__":
    print("\n🚀 Testing Complete Restaurant Booking System\n")
    print("Phase 1: Restaurant Discovery")
    print("Phase 2: Booking & Payment with SAGA Pattern\n")
    
    try:
        test_restaurant_search()
        test_complete_booking()
        test_user_registration()
        test_history_retrieval()
        
        print("\n✅ All tests completed!")
        print("\n📊 Summary:")
        print("   ✅ Phase 1: Restaurant Discovery")
        print("   ✅ Phase 2: User Management")
        print("   ✅ Phase 2: Token Calculation")
        print("   ✅ Phase 2: Booking Execution (SAGA)")
        print("   ✅ Phase 2: Payment Processing")
        print("   ✅ Memory Storage")
        
    except Exception as e:
        print(f"\n❌ Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
