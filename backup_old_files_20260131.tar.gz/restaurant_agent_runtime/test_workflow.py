"""
Local test script for Restaurant Discovery Agent
Tests the workflow before AgentCore Runtime deployment
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from restaurant_workflow import invoke

def test_restaurant_search():
    """Test restaurant search functionality"""
    print("=" * 80)
    print("TEST 1: Restaurant Search (Italian in New York)")
    print("=" * 80)
    
    payload = {
        "prompt": "Find Italian restaurants in New York",
        "user_id": "test_user_001",
        "session_id": "test_session_001",
        "search_params": {
            "city": "New York",
            "cuisine": "Italian"
        }
    }
    
    result = invoke(payload)
    print(f"\n✅ Result: {result.get('status')}")
    print(f"📍 Intent: {result.get('intent')}")
    print(f"🍽️ Restaurants Found: {len(result.get('restaurant_results', []))}")
    print(f"\n📝 Response:\n{result.get('final_response')}")
    print(f"\n💾 Memory Status: {result.get('memory_status')}")
    print("\n" + "=" * 80)

def test_restaurant_search_all():
    """Test fetching all restaurants"""
    print("\nTEST 2: Restaurant Search (All Restaurants)")
    print("=" * 80)
    
    payload = {
        "prompt": "Find restaurants",
        "user_id": "test_user_001",
        "session_id": "test_session_001",
        "search_params": {}  # No filters
    }
    
    result = invoke(payload)
    print(f"\n✅ Result: {result.get('status')}")
    print(f"📍 Intent: {result.get('intent')}")
    print(f"🍽️ Restaurants Found: {len(result.get('restaurant_results', []))}")
    if result.get('restaurant_results'):
        print(f"\n📝 Sample Results:")
        for i, r in enumerate(result.get('restaurant_results', [])[:3], 1):
            print(f"   {i}. {r.get('name')} - {r.get('cuisine')} - {r.get('location', {}).get('city')}")
    print(f"\n💾 Memory Status: {result.get('memory_status')}")
    print("\n" + "=" * 80)

def test_history_retrieval():
    """Test history retrieval functionality"""
    print("\nTEST 3: History Retrieval")
    print("=" * 80)
    
    payload = {
        "prompt": "Show me my search history",
        "user_id": "test_user_001",
        "session_id": "test_session_001"
    }
    
    result = invoke(payload)
    print(f"\n✅ Result: {result.get('status')}")
    print(f"📍 Intent: {result.get('intent')}")
    print(f"\n📝 Response:\n{result.get('final_response')}")
    print(f"\n💾 Memory Status: {result.get('memory_status')}")
    print("\n" + "=" * 80)

def test_error_handling():
    """Test error handling"""
    print("\nTEST 4: Error Handling")
    print("=" * 80)
    
    payload = {}  # Empty payload
    
    result = invoke(payload)
    print(f"\n✅ Result: {result.get('status')}")
    print(f"❌ Error: {result.get('error')}")
    print("\n" + "=" * 80)

if __name__ == "__main__":
    print("\n🚀 Starting Restaurant Discovery Agent Tests\n")
    
    try:
        test_restaurant_search()
        test_restaurant_search_all()
        test_history_retrieval()
        test_error_handling()
        
        print("\n✅ All tests completed!")
        
    except Exception as e:
        print(f"\n❌ Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
