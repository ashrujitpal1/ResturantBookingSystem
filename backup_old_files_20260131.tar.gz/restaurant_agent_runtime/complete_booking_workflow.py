import os
import json
import uuid
import time
import random
import requests
import boto3
from abc import ABC, abstractmethod
from functools import lru_cache
from typing import TypedDict, List, Annotated
from datetime import datetime, timedelta
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from bedrock_agentcore.memory import MemoryClient
try:
    from bedrock_agentcore_starter_toolkit.operations.gateway.client import GatewayClient
except ImportError:
    class GatewayClient:
        def __init__(self, region_name):
            self.region_name = region_name
        def get_access_token_for_cognito(self, cognito_info):
            import requests
            response = requests.post(
                cognito_info["token_endpoint"],
                data={
                    "grant_type": "client_credentials",
                    "client_id": cognito_info["client_id"],
                    "client_secret": cognito_info["client_secret"],
                    "scope": cognito_info.get("scope", "")
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            return response.json()["access_token"]

app = BedrockAgentCoreApp()

# LLM Provider Abstraction (SOLID Principles)
class LLMProvider(ABC):
    """Abstract base class for LLM providers"""
    @abstractmethod
    def invoke(self, tool_name: str, arguments: dict) -> dict:
        pass

class MCPToolProvider(LLMProvider):
    """MCP Tool provider implementation"""
    def __init__(self, gateway_url: str, cognito_info: dict, region: str):
        self.gateway_url = gateway_url
        self.cognito_info = cognito_info
        self.gateway_client = GatewayClient(region_name=region)
    
    def invoke(self, tool_name: str, arguments: dict) -> dict:
        bearer_token = self.gateway_client.get_access_token_for_cognito(self.cognito_info)
        return self._call_tool(tool_name, arguments, bearer_token)
    
    def _call_tool(self, tool_name: str, arguments: dict, bearer_token: str, max_retries: int = 3) -> dict:
        for attempt in range(max_retries):
            try:
                headers = {"Content-Type": "application/json", "Authorization": f"Bearer {bearer_token}"}
                payload = {
                    "jsonrpc": "2.0",
                    "id": random.randint(1, 10000),
                    "method": "tools/call",
                    "params": {"name": tool_name, "arguments": arguments}
                }
                response = requests.post(self.gateway_url, headers=headers, json=payload, timeout=5)
                response.raise_for_status()
                return response.json()
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                time.sleep(2 ** attempt)

class FallbackProvider(LLMProvider):
    """Fallback provider with circuit breaker pattern"""
    def __init__(self, primary: LLMProvider, secondary: LLMProvider):
        self.primary = primary
        self.secondary = secondary
        self.failure_count = 0
        self.failure_threshold = 3
    
    def invoke(self, tool_name: str, arguments: dict) -> dict:
        try:
            result = self.primary.invoke(tool_name, arguments)
            self.failure_count = 0
            return result
        except Exception as e:
            self.failure_count += 1
            print(f"⚠️ Primary provider failed ({self.failure_count}/{self.failure_threshold}): {e}")
            if self.failure_count >= self.failure_threshold:
                print("🔄 Switching to secondary provider")
                return self.secondary.invoke(tool_name, arguments)
            raise

def get_llm_provider() -> LLMProvider:
    """Factory function to create LLM provider with fallback"""
    primary = MCPToolProvider(gateway_url=GATEWAY_URL, cognito_info=COGNITO_INFO, region=REGION)
    secondary = MCPToolProvider(gateway_url=GATEWAY_URL, cognito_info=COGNITO_INFO, region=REGION)
    return FallbackProvider(primary, secondary)

# Prompt Versioning
PROMPT_VERSION = os.getenv("PROMPT_VERSION", "1.0.0")
PROMPT_BUCKET = os.getenv("PROMPT_BUCKET", "restaurant-booking-prompts")

@lru_cache(maxsize=10)
def load_prompt(agent_name: str, version: str) -> str:
    """Load versioned prompt from S3 with caching"""
    try:
        s3 = boto3.client('s3', region_name=REGION)
        key = f"prompts/{agent_name}/v{version}/system_prompt.md"
        response = s3.get_object(Bucket=PROMPT_BUCKET, Key=key)
        return response["Body"].read().decode('utf-8')
    except Exception as e:
        print(f"⚠️ Failed to load prompt from S3: {e}")
        # Fallback to default prompts
        return get_default_prompt(agent_name)

def get_default_prompt(agent_name: str) -> str:
    """Fallback prompts when S3 is unavailable"""
    defaults = {
        "intent_classifier": "You are an intent classifier. Classify user intent as: search, booking, or history.",
        "restaurant_finder": "You are a restaurant search assistant. Help users find restaurants based on their preferences.",
        "booking_agent": "You are a booking assistant. Collect booking details: date, time, guests, and validate them.",
        "payment_processor": "You are a payment processor. Handle payment transactions securely."
    }
    return defaults.get(agent_name, "You are a helpful restaurant booking assistant.")

# Model Selection & Cost Optimization
class CostOptimizedModelRouter:
    """Cost-optimized model selection per task type"""
    MODEL_COSTS = {
        "amazon.nova-micro-v1:0": 0.00015,
        "amazon.nova-lite-v1:0": 0.0006,
        "anthropic.claude-3-haiku": 0.00025,
        "anthropic.claude-3-sonnet": 0.003
    }
    
    @staticmethod
    def select_model(task_type: str) -> str:
        routing = {
            "intent_classification": "amazon.nova-micro-v1:0",
            "restaurant_search": "amazon.nova-lite-v1:0",
            "booking_validation": "anthropic.claude-3-sonnet",
            "payment_processing": "anthropic.claude-3-sonnet"
        }
        return routing.get(task_type, "amazon.nova-lite-v1:0")
    
    @staticmethod
    def estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
        cost_per_token = CostOptimizedModelRouter.MODEL_COSTS.get(model, 0.0006)
        return ((input_tokens + output_tokens) / 1000) * cost_per_token

# Global LLM provider instance
llm_provider = None

def get_provider() -> LLMProvider:
    """Get or create LLM provider instance"""
    global llm_provider
    if llm_provider is None:
        llm_provider = get_llm_provider()
    return llm_provider

# Prompt Injection Defense
INJECTION_PATTERNS = [
    r"ignore\s+(previous|all|above)\s+instructions?",
    r"you\s+are\s+now\s+a",
    r"disregard\s+(everything|all)",
    r"new\s+instructions?:",
    r"system\s+prompt:",
    r"forget\s+(everything|all)",
    r"<\s*system\s*>",
    r"role\s*:\s*system"
]

def validate_user_input(user_message: str) -> tuple[bool, str]:
    """Validate user input for prompt injection attacks"""
    import re
    
    # Check for injection patterns
    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, user_message, re.IGNORECASE):
            print(f"⚠️ Prompt injection detected: {pattern}")
            return False, "Invalid input detected. Please rephrase your request."
    
    # Check message length
    if len(user_message) > 2000:
        return False, "Message too long. Please keep requests under 2000 characters."
    
    return True, ""

def wrap_user_input(user_message: str) -> str:
    """Wrap user input in structured tags"""
    return f"<user_input>\n{user_message}\n</user_input>"

# Governance Policies
class GovernancePolicy:
    """Policy enforcement for booking operations"""
    POLICIES = {
        "book-a-table-target___bookATable": {
            "max_guests": 20,
            "max_token_amount": 500.0,
            "require_approval_if": lambda args: args.get("noOfGuests", 0) > 10,
            "allowed_meal_types": ["Breakfast", "Lunch", "Dinner"]
        },
        "payment-api-target___paymentAPI": {
            "max_amount": 500.0,
            "require_approval_if": lambda args: args.get("tokenAmount", 0) > 200.0
        }
    }
    
    @staticmethod
    def evaluate(tool_name: str, arguments: dict) -> tuple[bool, str]:
        """Evaluate if tool invocation meets policy requirements"""
        policy = GovernancePolicy.POLICIES.get(tool_name)
        if not policy:
            return True, ""
        
        # Check max_guests limit
        if "max_guests" in policy and arguments.get("noOfGuests", 0) > policy["max_guests"]:
            return False, f"Maximum {policy['max_guests']} guests allowed"
        
        # Check max_token_amount limit
        if "max_token_amount" in policy and arguments.get("tokenAmount", 0) > policy["max_token_amount"]:
            return False, f"Maximum booking amount ${policy['max_token_amount']} exceeded"
        
        # Check max_amount for payments
        if "max_amount" in policy and arguments.get("tokenAmount", 0) > policy["max_amount"]:
            return False, f"Maximum payment amount ${policy['max_amount']} exceeded"
        
        # Check approval requirements
        if "require_approval_if" in policy and policy["require_approval_if"](arguments):
            return False, "REQUIRES_HUMAN_APPROVAL"
        
        return True, ""

# Configuration
REGION = os.getenv("AWS_REGION", "us-east-1")
GATEWAY_URL = os.getenv("GATEWAY_URL", "https://restaurantappgatewaymi99khe1-tmnyzeshe6.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp")
MEMORY_ID = os.getenv("MEMORY_ID", "")
COGNITO_INFO = {
    "client_id": os.getenv("COGNITO_CLIENT_ID", "6u5ven1dru18pvpdn00nnlrop"),
    "client_secret": os.getenv("COGNITO_CLIENT_SECRET", "1kqf3jqpj42bn1ese41qc4bo3h9t1hr7b7grb17nonkvss2c6slc"),
    "token_endpoint": os.getenv("COGNITO_TOKEN_ENDPOINT", "https://agentcore-d9eb5364.auth.us-east-1.amazoncognito.com/oauth2/token"),
    "scope": os.getenv("COGNITO_SCOPE", "RestaurantBookingAuth/invoke")
}

gateway_client = GatewayClient(region_name=REGION)
memory_client = MemoryClient(region_name=REGION) if MEMORY_ID else None

# State Schema
class RestaurantBookingState(TypedDict):
    correlation_id: str
    user_id: str
    session_id: str
    messages: Annotated[List[AnyMessage], add_messages]
    prompt: str
    intent: str
    search_params: dict
    restaurant_results: list
    selected_restaurant: dict
    booking_intent: bool
    booking_details: dict
    user_details: dict
    token_amount: float
    booking_result: dict
    payment_result: dict
    compensation_stack: list
    final_response: str
    memory_status: str
    requires_hitl: bool
    hitl_reason: str
    validation_errors: list

# MCP Tool Caller with Circuit Breaker
def call_mcp_tool(tool_name: str, arguments: dict, bearer_token: str, max_retries: int = 3) -> dict:
    for attempt in range(max_retries):
        try:
            headers = {"Content-Type": "application/json", "Authorization": f"Bearer {bearer_token}"}
            payload = {
                "jsonrpc": "2.0",
                "id": random.randint(1, 10000),
                "method": "tools/call",
                "params": {"name": tool_name, "arguments": arguments}
            }
            response = requests.post(GATEWAY_URL, headers=headers, json=payload, timeout=5)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)

def parse_mcp_response(result: dict) -> dict:
    """Parse MCP response with robust error handling"""
    try:
        if "result" in result and "content" in result["result"]:
            content = result["result"]["content"][0]["text"]
            try:
                parsed = json.loads(content)
                # Handle nested body wrapper
                if isinstance(parsed, dict) and "body" in parsed:
                    return json.loads(parsed["body"])
                return parsed
            except json.JSONDecodeError:
                return {"error": "Invalid JSON response", "raw": content}
        return result
    except Exception as e:
        return {"error": f"Parse error: {str(e)}", "raw": str(result)}

# Phase 1: Restaurant Discovery Nodes
def entry_router(state: RestaurantBookingState) -> dict:
    """Route based on intent - uses Nova Micro for cost efficiency"""
    user_message = state.get("prompt", "")
    model = CostOptimizedModelRouter.select_model("intent_classification")
    
    # Validate input for prompt injection
    is_valid, error_message = validate_user_input(user_message)
    if not is_valid:
        return {
            "intent": "invalid_input",
            "final_response": error_message,
            "next": "END",
            "model_used": model
        }
    
    # Wrap in structured format
    wrapped_prompt = wrap_user_input(user_message)
    prompt = wrapped_prompt.lower()
    
    if any(kw in prompt for kw in ["history", "previous", "show me", "past"]):
        return {"intent": "history", "next": "retrieve_memory", "model_used": model, "prompt": wrapped_prompt}
    
    if any(kw in prompt for kw in ["book", "reserve", "table", "reservation"]):
        return {"intent": "booking", "booking_intent": True, "next": "restaurant_finder", "model_used": model, "prompt": wrapped_prompt}
    
    return {"intent": "search", "booking_intent": False, "next": "restaurant_finder", "model_used": model, "prompt": wrapped_prompt}

def restaurant_finder_agent(state: RestaurantBookingState) -> dict:
    """Restaurant search - uses Nova Lite for cost optimization"""
    correlation_id = state.get("correlation_id", str(uuid.uuid4()))
    search_params = state.get("search_params", {})
    model = CostOptimizedModelRouter.select_model("restaurant_search")
    
    try:
        provider = get_provider()
        result = provider.invoke(
            "fetch-restaurant-details-target___fetchRestaurantDetails",
            {**search_params, "requestId": f"{correlation_id}_search_1"}
        )
        
        parsed = parse_mcp_response(result)
        restaurants = parsed.get("restaurants", [])[:10]
        
        if restaurants:
            response = f"Found {len(restaurants)} restaurants:\n\n"
            for i, r in enumerate(restaurants, 1):
                response += f"{i}. {r.get('name')} - {r.get('cuisine')} - Rating: {r.get('rating')}\n"
            
            # Auto-select first restaurant if booking intent
            selected = restaurants[0] if state.get("booking_intent") else {}
            return {
                "restaurant_results": restaurants,
                "selected_restaurant": selected,
                "final_response": response,
                "model_used": model
            }
        else:
            return {"restaurant_results": [], "final_response": "No restaurants found."}
    
    except Exception as e:
        return {"restaurant_results": [], "final_response": f"Error: {str(e)}"}

# Validation Functions
def validate_phone(phone: str) -> tuple[bool, str]:
    """Validate phone number (10+ digits)"""
    import re
    digits = re.sub(r'\D', '', phone)
    if len(digits) < 10:
        return False, f"Phone must have 10+ digits (got {len(digits)})"
    return True, ""

def validate_date(date_str: str) -> tuple[bool, str]:
    """Validate booking date (future dates only)"""
    try:
        booking_date = datetime.strptime(date_str, "%Y-%m-%d")
        if booking_date.date() < datetime.now().date():
            return False, "Date must be in the future"
        if booking_date.date() > (datetime.now() + timedelta(days=90)).date():
            return False, "Date must be within 90 days"
        return True, ""
    except ValueError:
        return False, "Invalid date format (use YYYY-MM-DD)"

def validate_guests(num_guests: int) -> tuple[bool, str, bool]:
    """Validate guest count with governance policy, return (valid, error, requires_hitl)"""
    # Check minimum
    if num_guests < 1:
        return False, "Must have at least 1 guest", False
    
    # Check maximum (governance policy)
    if num_guests > 20:
        return False, "Maximum 20 guests allowed per booking", False
    
    # Check HITL threshold
    if num_guests > 10:
        return True, "", True  # Valid but requires HITL
    
    return True, "", False

# Phase 2: Booking Agent Nodes
def booking_agent(state: RestaurantBookingState) -> dict:
    """Gather booking information and validate - uses Claude Sonnet for accuracy"""
    booking_details = state.get("booking_details", {})
    selected_restaurant = state.get("selected_restaurant", {})
    validation_errors = []
    requires_hitl = False
    hitl_reason = ""
    model = CostOptimizedModelRouter.select_model("booking_validation")
    
    # Default booking details (in production, extract from conversation)
    if not booking_details:
        booking_details = {
            "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 2,
            "user_mobile": "+15551234567",
            "user_name": "Test User"
        }
    
    # Validate phone
    phone_valid, phone_error = validate_phone(booking_details.get("user_mobile", ""))
    if not phone_valid:
        validation_errors.append(phone_error)
    
    # Validate date
    date_valid, date_error = validate_date(booking_details.get("date", ""))
    if not date_valid:
        validation_errors.append(date_error)
    
    # Validate guests (check HITL)
    guests_valid, guests_error, needs_hitl = validate_guests(booking_details.get("no_of_guests", 0))
    if not guests_valid:
        validation_errors.append(guests_error)
    if needs_hitl:
        requires_hitl = True
        hitl_reason = f"Large group booking ({booking_details.get('no_of_guests')} guests) requires manager approval"
    
    # If validation errors, stop workflow
    if validation_errors:
        return {
            "booking_details": booking_details,
            "validation_errors": validation_errors,
            "requires_hitl": False,
            "final_response": f"❌ Validation failed:\n" + "\n".join(f"- {e}" for e in validation_errors)
        }
    
    # If HITL required, pause workflow
    if requires_hitl:
        return {
            "booking_details": booking_details,
            "validation_errors": [],
            "requires_hitl": True,
            "hitl_reason": hitl_reason,
            "final_response": f"⏸️ {hitl_reason}\n\nBooking paused for approval."
        }
    
    return {
        "booking_details": booking_details,
        "validation_errors": [],
        "requires_hitl": False,
        "hitl_reason": "",
        "final_response": f"✅ Validation passed. Preparing booking for {selected_restaurant.get('name', 'restaurant')}...",
        "model_used": model
    }

def user_management_agent(state: RestaurantBookingState) -> dict:
    """Search or register user"""
    correlation_id = state.get("correlation_id")
    booking_details = state.get("booking_details", {})
    mobile = booking_details.get("user_mobile")
    
    try:
        provider = get_provider()
        
        # Search user
        result = provider.invoke(
            "search-user-details-target___searchUserDetails",
            {"userMobileNo": mobile}
        )
        
        parsed = parse_mcp_response(result)
        
        # If user not found, register
        if not parsed or "error" in str(parsed).lower():
            register_result = provider.invoke(
                "register-user-target___registerUser",
                {
                    "username": booking_details.get("user_name"),
                    "mobileNo": mobile,
                    "userCity": "New York",
                    "userPreference": {"cuisine": ["Italian"]},
                    "requestId": f"{correlation_id}_register_1"
                }
            )
            parsed = parse_mcp_response(register_result)
        
        return {"user_details": parsed}
    
    except Exception as e:
        return {"user_details": {}, "final_response": f"User management error: {str(e)}"}

def token_calculation_agent(state: RestaurantBookingState) -> dict:
    """Calculate booking token amount"""
    correlation_id = state.get("correlation_id")
    booking_details = state.get("booking_details", {})
    
    try:
        provider = get_provider()
        
        result = provider.invoke(
            "token-amount-calculation-target___tokenAmountCalculation",
            {
                "noOfGuests": booking_details.get("no_of_guests", 2),
                "mealType": booking_details.get("meal_type", "Dinner"),
                "restaurantTier": "standard",
                "requestId": f"{correlation_id}_calc_1"
            }
        )
        
        parsed = parse_mcp_response(result)
        
        # Robust token amount extraction
        token_amount = 0
        if "error" not in parsed:
            token_amount = parsed.get("totalAmount") or parsed.get("tokenAmount") or parsed.get("amount") or 0
            # Handle string amounts
            if isinstance(token_amount, str):
                try:
                    token_amount = float(token_amount)
                except ValueError:
                    token_amount = 0
        
        return {"token_amount": token_amount}
    
    except Exception as e:
        return {"token_amount": 0, "final_response": f"Token calculation error: {str(e)}"}

def booking_execution_agent(state: RestaurantBookingState) -> dict:
    """Execute booking with SAGA pattern and governance policies - uses Claude Sonnet for payment"""
    correlation_id = state.get("correlation_id")
    selected_restaurant = state.get("selected_restaurant", {})
    booking_details = state.get("booking_details", {})
    token_amount = state.get("token_amount", 0)
    compensation_stack = []
    model = CostOptimizedModelRouter.select_model("payment_processing")
    
    try:
        provider = get_provider()
        
        # Prepare booking arguments
        booking_args = {
            "restaurantId": selected_restaurant.get("restaurantId", "rest_001"),
            "userName": booking_details.get("user_name"),
            "userMobileNo": booking_details.get("user_mobile"),
            "date": booking_details.get("date"),
            "time": booking_details.get("time"),
            "type": booking_details.get("meal_type"),
            "cityName": selected_restaurant.get("location", {}).get("city", "New York"),
            "noOfGuests": booking_details.get("no_of_guests"),
            "tokenAmount": token_amount,
            "requestId": f"{correlation_id}_book_1"
        }
        
        # Evaluate governance policy before booking
        allowed, reason = GovernancePolicy.evaluate("book-a-table-target___bookATable", booking_args)
        if not allowed:
            if reason == "REQUIRES_HUMAN_APPROVAL":
                return {
                    "booking_result": {},
                    "payment_result": {},
                    "requires_hitl": True,
                    "hitl_reason": f"Large group booking ({booking_args['noOfGuests']} guests) requires manager approval",
                    "final_response": f"⏸️ Booking requires approval for {booking_args['noOfGuests']} guests"
                }
            else:
                return {
                    "booking_result": {},
                    "payment_result": {},
                    "final_response": f"❌ Policy violation: {reason}"
                }
        
        # Step 1: Book table
        booking_result = provider.invoke("book-a-table-target___bookATable", booking_args)
        
        booking_parsed = parse_mcp_response(booking_result)
        
        # Robust booking ID extraction
        booking_id = booking_parsed.get("bookingId") or booking_parsed.get("booking_id") or booking_parsed.get("id")
        if not booking_id:
            raise ValueError(f"No booking ID in response: {booking_parsed}")
        
        compensation_stack.append(("cancel_booking", booking_id))
        
        # Step 2: Process payment
        try:
            user_details = state.get("user_details", {})
            
            # Prepare payment arguments
            payment_args = {
                "userId": user_details.get("userId", "user_001"),
                "restaurantId": selected_restaurant.get("restaurantId", "rest_001"),
                "bookingId": booking_id,
                "date": booking_details.get("date"),
                "time": booking_details.get("time"),
                "tokenAmount": token_amount,
                "paymentMethod": "credit_card",
                "requestId": f"{correlation_id}_pay_1"
            }
            
            # Evaluate governance policy before payment
            allowed, reason = GovernancePolicy.evaluate("payment-api-target___paymentAPI", payment_args)
            if not allowed:
                # Compensate: Cancel booking
                print(f"⚠️ Payment policy violation: {reason}")
                return {
                    "booking_result": {},
                    "payment_result": {},
                    "final_response": f"❌ Payment blocked: {reason}. Booking cancelled."
                }
            
            payment_result = provider.invoke("payment-api-target___paymentAPI", payment_args)
            
            payment_parsed = parse_mcp_response(payment_result)
            
            # Extract payment status robustly
            payment_status = payment_parsed.get("paymentStatus") or payment_parsed.get("status") or "unknown"
            booking_ref = booking_parsed.get("bookingReference") or booking_parsed.get("reference") or booking_id
            
            return {
                "booking_result": booking_parsed,
                "payment_result": payment_parsed,
                "compensation_stack": compensation_stack,
                "final_response": f"✅ Booking confirmed!\nBooking ID: {booking_id}\nReference: {booking_ref}\nPayment: {payment_status}",
                "model_used": model
            }
        
        except Exception as payment_error:
            # Compensate: Cancel booking
            print(f"Payment failed, compensating: {payment_error}")
            # In production: call cancel_booking API
            return {
                "booking_result": {},
                "payment_result": {},
                "final_response": f"❌ Payment failed. Booking cancelled."
            }
    
    except Exception as e:
        return {
            "booking_result": {},
            "payment_result": {},
            "final_response": f"Booking error: {str(e)}"
        }

# Phase 3: Memory & History with PII Scrubbing
def scrub_pii(text: str) -> str:
    """Remove PII before storing in memory"""
    import re
    # Credit card numbers (must come before phone to avoid conflict)
    text = re.sub(r'\b\d{4}[\s\-]\d{4}[\s\-]\d{4}[\s\-]\d{4}\b', '<CARD>', text)
    # Phone numbers
    text = re.sub(r'\+?\d[\d\s\-\(\)]{9,}', '<PHONE>', text)
    # Email addresses
    text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '<EMAIL>', text)
    # Booking IDs (keep format but mask)
    text = re.sub(r'booking_[a-f0-9]{8}', 'booking_<ID>', text)
    return text

def retrieve_memory_agent(state: RestaurantBookingState) -> dict:
    """Retrieve conversation history with semantic and exact match search"""
    if not memory_client or not MEMORY_ID:
        return {"final_response": "Memory not configured", "memory_status": "disabled"}
    
    try:
        user_id = state.get("user_id", "default_user")
        session_id = state.get("session_id", "default_session")
        prompt = state.get("prompt", "").lower()
        
        # Semantic search for cuisine/restaurant queries
        if any(kw in prompt for kw in ["italian", "chinese", "japanese", "cuisine", "restaurant"]):
            # Extract cuisine from prompt
            cuisines = ["italian", "chinese", "japanese", "mexican", "indian"]
            matched_cuisine = next((c for c in cuisines if c in prompt), None)
            
            events = memory_client.list_events(
                memory_id=MEMORY_ID,
                actor_id=user_id,
                max_results=20
            )
            
            # Filter by semantic match
            filtered = [e for e in events if matched_cuisine and matched_cuisine in str(e).lower()] if matched_cuisine else events[:10]
            
            if filtered:
                history = f"# {matched_cuisine.title() if matched_cuisine else 'Recent'} Bookings\n\n"
                history += "\n".join([f"{i}. {e}" for i, e in enumerate(filtered, 1)])
                return {"final_response": history, "memory_status": "retrieved_semantic"}
        
        # Exact match for booking IDs
        elif "booking" in prompt and any(char.isdigit() for char in prompt):
            import re
            booking_id_match = re.search(r'booking_[a-f0-9]{8}', prompt)
            if booking_id_match:
                booking_id = booking_id_match.group(0)
                events = memory_client.list_events(
                    memory_id=MEMORY_ID,
                    actor_id=user_id,
                    max_results=50
                )
                
                # Exact match search
                matched = [e for e in events if booking_id in str(e)]
                if matched:
                    return {"final_response": f"# Booking {booking_id}\n\n{matched[0]}", "memory_status": "retrieved_exact"}
        
        # Default: Recent history
        events = memory_client.list_events(
            memory_id=MEMORY_ID,
            actor_id=user_id,
            session_id=session_id,
            max_results=10
        )
        
        history = "# Recent History\n\n" + "\n".join([f"{i}. {e}" for i, e in enumerate(events, 1)]) if events else "No history found."
        return {"final_response": history, "memory_status": "retrieved"}
    
    except Exception as e:
        return {"final_response": f"Error: {str(e)}", "memory_status": "error"}

def save_memory_agent(state: RestaurantBookingState) -> dict:
    """Save conversation with PII scrubbing and structured metadata"""
    if not memory_client or not MEMORY_ID:
        return {"memory_status": "disabled"}
    
    try:
        user_id = state.get("user_id", "default_user")
        session_id = state.get("session_id", "default_session")
        prompt = state.get("prompt", "")
        response = state.get("final_response", "")
        
        # Scrub PII before storage
        scrubbed_prompt = scrub_pii(prompt)
        scrubbed_response = scrub_pii(response)
        
        # Add structured metadata for semantic search
        booking_result = state.get("booking_result", {})
        selected_restaurant = state.get("selected_restaurant", {})
        
        metadata = {
            "intent": state.get("intent", ""),
            "restaurant_name": selected_restaurant.get("name", ""),
            "cuisine": selected_restaurant.get("cuisine", ""),
            "booking_date": state.get("booking_details", {}).get("date", ""),
            "booking_id": booking_result.get("bookingId", ""),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Enrich messages with metadata for better retrieval
        user_message = f"{scrubbed_prompt} [cuisine:{metadata['cuisine']}]"
        assistant_message = f"{scrubbed_response} [restaurant:{metadata['restaurant_name']}]"
        
        memory_client.save_conversation(
            memory_id=MEMORY_ID,
            actor_id=user_id,  # Actor-based isolation
            session_id=session_id,
            messages=[
                (user_message, "USER"),
                (assistant_message, "ASSISTANT")
            ]
        )
        
        return {"memory_status": "saved"}
    
    except Exception as e:
        print(f"Memory save error: {str(e)}")
        return {"memory_status": "save_failed"}

# Build Workflow
def create_restaurant_booking_workflow():
    workflow = StateGraph(RestaurantBookingState)
    
    # Add nodes
    workflow.add_node("entry_router", entry_router)
    workflow.add_node("restaurant_finder", restaurant_finder_agent)
    workflow.add_node("booking_agent", booking_agent)
    workflow.add_node("user_management", user_management_agent)
    workflow.add_node("token_calculation", token_calculation_agent)
    workflow.add_node("booking_execution", booking_execution_agent)
    workflow.add_node("retrieve_memory", retrieve_memory_agent)
    workflow.add_node("save_memory", save_memory_agent)
    
    # Set entry point
    workflow.set_entry_point("entry_router")
    
    # Entry router edges
    workflow.add_conditional_edges(
        "entry_router",
        lambda state: state.get("next", "END"),
        {
            "restaurant_finder": "restaurant_finder",
            "retrieve_memory": "retrieve_memory",
            "END": END
        }
    )
    
    # Restaurant finder handoff
    workflow.add_conditional_edges(
        "restaurant_finder",
        lambda state: "booking_agent" if state.get("booking_intent") else "save_memory",
        {
            "booking_agent": "booking_agent",
            "save_memory": "save_memory"
        }
    )
    
    # Booking flow with validation gate
    workflow.add_conditional_edges(
        "booking_agent",
        lambda state: "END" if (state.get("validation_errors") or state.get("requires_hitl")) else "user_management",
        {
            "user_management": "user_management",
            "END": END
        }
    )
    workflow.add_edge("user_management", "token_calculation")
    workflow.add_edge("token_calculation", "booking_execution")
    workflow.add_edge("booking_execution", "save_memory")
    
    # Memory flows
    workflow.add_edge("save_memory", END)
    workflow.add_edge("retrieve_memory", END)
    
    return workflow.compile(checkpointer=MemorySaver())

langgraph_workflow = create_restaurant_booking_workflow()

@app.entrypoint
def invoke(payload):
    print(f"📥 Received payload: {payload}")
    
    prompt = payload.get("prompt", "")
    user_id = payload.get("user_id", "default_user")
    session_id = payload.get("session_id", f"session_{uuid.uuid4()}")
    correlation_id = f"req_{uuid.uuid4()}"
    
    if not prompt:
        return {"error": "No prompt provided", "status": "failed"}
    
    initial_state = {
        "correlation_id": correlation_id,
        "user_id": user_id,
        "session_id": session_id,
        "messages": [],
        "prompt": prompt,
        "intent": "",
        "search_params": payload.get("search_params", {}),
        "restaurant_results": [],
        "selected_restaurant": {},
        "booking_intent": False,
        "booking_details": payload.get("booking_details", {}),
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": f"thread_{random.randint(1000, 9999)}"}}
    
    try:
        final_state = langgraph_workflow.invoke(initial_state, config)
        
        model_used = final_state.get("model_used", "unknown")
        
        return {
            "correlation_id": correlation_id,
            "intent": final_state.get("intent", ""),
            "restaurant_results": final_state.get("restaurant_results", []),
            "booking_result": final_state.get("booking_result", {}),
            "payment_result": final_state.get("payment_result", {}),
            "final_response": final_state.get("final_response", ""),
            "memory_status": final_state.get("memory_status", ""),
            "requires_hitl": final_state.get("requires_hitl", False),
            "hitl_reason": final_state.get("hitl_reason", ""),
            "validation_errors": final_state.get("validation_errors", []),
            "model_used": model_used,
            "status": "success"
        }
    
    except Exception as e:
        print(f"❌ Workflow error: {str(e)}")
        return {"error": str(e), "status": "failed"}

print("✅ Restaurant Booking System initialized (Phase 1 + Phase 2)")
