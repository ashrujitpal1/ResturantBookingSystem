#!/usr/bin/env python3
"""End-to-end integration test demonstrating all production fixes"""

import sys
import json
from datetime import datetime, timedelta
from complete_booking_workflow import langgraph_workflow

def test_scenario_1_normal_booking():
    """Scenario 1: Normal booking (2 guests) - Should succeed"""
    print("\n" + "="*70)
    print("SCENARIO 1: Normal Booking (2 guests)")
    print("="*70)
    
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    
    payload = {
        "correlation_id": "test_normal_001",
        "user_id": "user_001",
        "session_id": "session_001",
        "messages": [],
        "prompt": "Book a table for 2 at Italian Bistro tomorrow at 7pm",
        "intent": "booking",
        "search_params": {"cuisine": "Italian"},
        "restaurant_results": [],
        "selected_restaurant": {
            "restaurantId": "rest_001",
            "name": "Italian Bistro",
            "cuisine": "Italian",
            "rating": 4.5,
            "location": {"city": "New York"}
        },
        "booking_intent": True,
        "booking_details": {
            "date": tomorrow,
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 2,
            "user_mobile": "+15551234567",
            "user_name": "John Doe"
        },
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": "thread_normal"}}
    
    try:
        print(f"\n📝 Booking Details:")
        print(f"   Restaurant: {payload['selected_restaurant']['name']}")
        print(f"   Date: {payload['booking_details']['date']}")
        print(f"   Guests: {payload['booking_details']['no_of_guests']}")
        print(f"   Phone: {payload['booking_details']['user_mobile']}")
        
        print(f"\n🔄 Processing...")
        result = langgraph_workflow.invoke(payload, config)
        
        print(f"\n✅ Result:")
        print(f"   Status: {result.get('status', 'unknown')}")
        print(f"   Requires HITL: {result.get('requires_hitl', False)}")
        print(f"   Validation Errors: {len(result.get('validation_errors', []))}")
        print(f"   Response: {result.get('final_response', '')[:150]}")
        
        # Should succeed without HITL
        if not result.get('requires_hitl') and not result.get('validation_errors'):
            print(f"\n🎉 SUCCESS: Normal booking processed automatically")
            return True
        else:
            print(f"\n❌ FAILED: Unexpected HITL or validation errors")
            return False
    
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        return False

def test_scenario_2_large_group():
    """Scenario 2: Large group (15 guests) - Should trigger HITL"""
    print("\n" + "="*70)
    print("SCENARIO 2: Large Group Booking (15 guests)")
    print("="*70)
    
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    
    payload = {
        "correlation_id": "test_large_001",
        "user_id": "user_002",
        "session_id": "session_002",
        "messages": [],
        "prompt": "Book a table for 15 people",
        "intent": "booking",
        "search_params": {},
        "restaurant_results": [],
        "selected_restaurant": {
            "restaurantId": "rest_002",
            "name": "Grand Banquet Hall",
            "cuisine": "American",
            "rating": 4.8
        },
        "booking_intent": True,
        "booking_details": {
            "date": tomorrow,
            "time": "18:00",
            "meal_type": "Dinner",
            "no_of_guests": 15,
            "user_mobile": "+15559876543",
            "user_name": "Jane Smith"
        },
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": "thread_large"}}
    
    try:
        print(f"\n📝 Booking Details:")
        print(f"   Restaurant: {payload['selected_restaurant']['name']}")
        print(f"   Date: {payload['booking_details']['date']}")
        print(f"   Guests: {payload['booking_details']['no_of_guests']} ⚠️")
        print(f"   Phone: {payload['booking_details']['user_mobile']}")
        
        print(f"\n🔄 Processing...")
        result = langgraph_workflow.invoke(payload, config)
        
        print(f"\n⏸️  Result:")
        print(f"   Status: {result.get('status', 'unknown')}")
        print(f"   Requires HITL: {result.get('requires_hitl', False)}")
        print(f"   HITL Reason: {result.get('hitl_reason', 'N/A')}")
        print(f"   Validation Errors: {len(result.get('validation_errors', []))}")
        print(f"   Response: {result.get('final_response', '')[:150]}")
        
        # Should trigger HITL
        if result.get('requires_hitl') and "15 guests" in result.get('hitl_reason', ''):
            print(f"\n🎉 SUCCESS: HITL correctly triggered for large group")
            return True
        else:
            print(f"\n❌ FAILED: HITL not triggered as expected")
            return False
    
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        return False

def test_scenario_3_validation_errors():
    """Scenario 3: Invalid data - Should reject with clear errors"""
    print("\n" + "="*70)
    print("SCENARIO 3: Invalid Data (bad phone + past date)")
    print("="*70)
    
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    payload = {
        "correlation_id": "test_invalid_001",
        "user_id": "user_003",
        "session_id": "session_003",
        "messages": [],
        "prompt": "Book a table",
        "intent": "booking",
        "search_params": {},
        "restaurant_results": [],
        "selected_restaurant": {
            "restaurantId": "rest_003",
            "name": "Test Restaurant",
            "cuisine": "Italian"
        },
        "booking_intent": True,
        "booking_details": {
            "date": yesterday,  # Invalid: past date
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 4,
            "user_mobile": "123",  # Invalid: too short
            "user_name": "Bob Johnson"
        },
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": "thread_invalid"}}
    
    try:
        print(f"\n📝 Booking Details:")
        print(f"   Restaurant: {payload['selected_restaurant']['name']}")
        print(f"   Date: {payload['booking_details']['date']} ❌ (past)")
        print(f"   Guests: {payload['booking_details']['no_of_guests']}")
        print(f"   Phone: {payload['booking_details']['user_mobile']} ❌ (too short)")
        
        print(f"\n🔄 Processing...")
        result = langgraph_workflow.invoke(payload, config)
        
        print(f"\n❌ Result:")
        print(f"   Status: {result.get('status', 'unknown')}")
        print(f"   Validation Errors: {len(result.get('validation_errors', []))}")
        for i, error in enumerate(result.get('validation_errors', []), 1):
            print(f"      {i}. {error}")
        print(f"   Response: {result.get('final_response', '')[:200]}")
        
        # Should have validation errors
        errors = result.get('validation_errors', [])
        if len(errors) >= 2 and any('phone' in e.lower() for e in errors) and any('date' in e.lower() for e in errors):
            print(f"\n🎉 SUCCESS: Validation errors correctly caught")
            return True
        else:
            print(f"\n❌ FAILED: Expected 2+ validation errors (phone + date)")
            return False
    
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        return False

def test_scenario_4_edge_case():
    """Scenario 4: Edge case (10 guests) - Should succeed without HITL"""
    print("\n" + "="*70)
    print("SCENARIO 4: Edge Case (10 guests - max without HITL)")
    print("="*70)
    
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    
    payload = {
        "correlation_id": "test_edge_001",
        "user_id": "user_004",
        "session_id": "session_004",
        "messages": [],
        "prompt": "Book a table for 10 people",
        "intent": "booking",
        "search_params": {},
        "restaurant_results": [],
        "selected_restaurant": {
            "restaurantId": "rest_004",
            "name": "Family Restaurant",
            "cuisine": "American"
        },
        "booking_intent": True,
        "booking_details": {
            "date": tomorrow,
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 10,  # Edge case: exactly 10
            "user_mobile": "+15551112222",
            "user_name": "Alice Brown"
        },
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": "thread_edge"}}
    
    try:
        print(f"\n📝 Booking Details:")
        print(f"   Restaurant: {payload['selected_restaurant']['name']}")
        print(f"   Date: {payload['booking_details']['date']}")
        print(f"   Guests: {payload['booking_details']['no_of_guests']} (edge case)")
        print(f"   Phone: {payload['booking_details']['user_mobile']}")
        
        print(f"\n🔄 Processing...")
        result = langgraph_workflow.invoke(payload, config)
        
        print(f"\n✅ Result:")
        print(f"   Status: {result.get('status', 'unknown')}")
        print(f"   Requires HITL: {result.get('requires_hitl', False)}")
        print(f"   Validation Errors: {len(result.get('validation_errors', []))}")
        print(f"   Response: {result.get('final_response', '')[:150]}")
        
        # Should succeed without HITL (10 is the max)
        if not result.get('requires_hitl') and not result.get('validation_errors'):
            print(f"\n🎉 SUCCESS: 10 guests processed without HITL")
            return True
        else:
            print(f"\n❌ FAILED: Should not require HITL for 10 guests")
            return False
    
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        return False

def main():
    print("\n" + "="*70)
    print("🎬 END-TO-END INTEGRATION TEST")
    print("="*70)
    print("Testing all production fixes in realistic scenarios")
    
    scenarios = [
        ("Normal Booking (2 guests)", test_scenario_1_normal_booking),
        ("Large Group (15 guests)", test_scenario_2_large_group),
        ("Invalid Data", test_scenario_3_validation_errors),
        ("Edge Case (10 guests)", test_scenario_4_edge_case)
    ]
    
    results = {}
    for name, test_func in scenarios:
        results[name] = test_func()
    
    print("\n" + "="*70)
    print("📊 INTEGRATION TEST RESULTS")
    print("="*70)
    
    for scenario, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} - {scenario}")
    
    total_passed = sum(results.values())
    total_tests = len(results)
    
    print(f"\n🎯 Overall: {total_passed}/{total_tests} scenarios passed")
    
    if total_passed == total_tests:
        print("\n" + "="*70)
        print("🎉 ALL SCENARIOS PASSED - PRODUCTION READY!")
        print("="*70)
        print("\n✅ Response Parsing: Working with multiple field fallbacks")
        print("✅ HITL Workflow: Correctly triggered for 11+ guests")
        print("✅ Validation: Phone, date, and guest validation working")
        print("✅ Error Handling: Clear, actionable error messages")
        print("\n🚀 Ready for AWS Bedrock AgentCore Runtime deployment")
        return 0
    else:
        print("\n⚠️  Some scenarios failed - review output above")
        return 1

if __name__ == "__main__":
    sys.exit(main())
