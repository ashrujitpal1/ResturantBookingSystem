import os
import json
import uuid
import time
import random
import requests
from typing import TypedDict, List, Annotated
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from bedrock_agentcore.memory import MemoryClient
try:
    from bedrock_agentcore_starter_toolkit.operations.gateway.client import GatewayClient
except ImportError:
    # Fallback for runtime environment
    class GatewayClient:
        def __init__(self, region_name):
            self.region_name = region_name
        
        def get_access_token_for_cognito(self, cognito_info):
            import requests
            response = requests.post(
                cognito_info["token_endpoint"],
                data={
                    "grant_type": "client_credentials",
                    "client_id": cognito_info["client_id"],
                    "client_secret": cognito_info["client_secret"],
                    "scope": cognito_info.get("scope", "")
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            return response.json()["access_token"]

# AgentCore App
app = BedrockAgentCoreApp()

# Configuration - Load from environment or config file
REGION = os.getenv("AWS_REGION", "us-east-1")
GATEWAY_URL = os.getenv("GATEWAY_URL", "https://restaurantappgatewaymi99khe1-tmnyzeshe6.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp")
MEMORY_ID = os.getenv("MEMORY_ID", "")
COGNITO_INFO = {
    "client_id": os.getenv("COGNITO_CLIENT_ID", "6u5ven1dru18pvpdn00nnlrop"),
    "client_secret": os.getenv("COGNITO_CLIENT_SECRET", "1kqf3jqpj42bn1ese41qc4bo3h9t1hr7b7grb17nonkvss2c6slc"),
    "token_endpoint": os.getenv("COGNITO_TOKEN_ENDPOINT", "https://agentcore-d9eb5364.auth.us-east-1.amazoncognito.com/oauth2/token"),
    "scope": os.getenv("COGNITO_SCOPE", "RestaurantBookingAuth/invoke")
}

# Clients
gateway_client = GatewayClient(region_name=REGION)
memory_client = MemoryClient(region_name=REGION) if MEMORY_ID else None

# State Schema
class RestaurantDiscoveryState(TypedDict):
    correlation_id: str
    user_id: str
    session_id: str
    messages: Annotated[List[AnyMessage], add_messages]
    prompt: str
    intent: str
    search_params: dict
    restaurant_results: list
    final_response: str
    memory_status: str

# MCP Tool Caller with Circuit Breaker
def call_mcp_tool(tool_name: str, arguments: dict, bearer_token: str, max_retries: int = 3) -> dict:
    """Call MCP tool with circuit breaker and exponential backoff"""
    for attempt in range(max_retries):
        try:
            headers = {"Content-Type": "application/json", "Authorization": f"Bearer {bearer_token}"}
            payload = {
                "jsonrpc": "2.0",
                "id": random.randint(1, 10000),
                "method": "tools/call",
                "params": {"name": tool_name, "arguments": arguments}
            }
            response = requests.post(GATEWAY_URL, headers=headers, json=payload, timeout=5)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)  # Exponential backoff

def parse_mcp_response(result: dict) -> dict:
    """Parse MCP response with error handling"""
    try:
        if "result" in result and "content" in result["result"]:
            content = result["result"]["content"][0]["text"]
            # Try direct JSON parse first (new format)
            try:
                return json.loads(content)
            except:
                # Fall back to nested body format (old format)
                outer_json = json.loads(content)
                body_json = json.loads(outer_json["body"])
                return body_json
        return result
    except Exception as e:
        print(f"❌ Parse error: {e}")
        return result

# Workflow Nodes
def entry_router(state: RestaurantDiscoveryState) -> dict:
    """Route based on intent: search or history"""
    prompt = state.get("prompt", "").lower()
    
    # History keywords
    if any(kw in prompt for kw in ["history", "previous", "show me", "past"]):
        return {"intent": "history", "next": "retrieve_memory"}
    
    # Search intent
    return {"intent": "search", "next": "restaurant_finder"}

def restaurant_finder_agent(state: RestaurantDiscoveryState) -> dict:
    """Search restaurants using MCP tools with idempotency"""
    correlation_id = state.get("correlation_id", str(uuid.uuid4()))
    prompt = state.get("prompt", "")
    search_params = state.get("search_params", {})
    
    # Extract search parameters from prompt (simple keyword extraction)
    city = search_params.get("city", "")
    cuisine = search_params.get("cuisine", "")
    
    # Simple extraction if not provided
    if not city:
        for word in prompt.split():
            if word.capitalize() in ["New", "York", "Boston", "Chicago", "Seattle"]:
                city = word.capitalize()
    
    if not cuisine:
        for word in prompt.split():
            if word.capitalize() in ["Italian", "Chinese", "Mexican", "Japanese", "Indian"]:
                cuisine = word.capitalize()
    
    try:
        bearer_token = gateway_client.get_access_token_for_cognito(COGNITO_INFO)
        
        # Idempotent tool call
        result = call_mcp_tool(
            "fetch-restaurant-details-target___fetchRestaurantDetails",
            {
                "city": city,
                "cuisine": cuisine,
                "requestId": f"{correlation_id}_search_1"
            },
            bearer_token
        )
        
        parsed = parse_mcp_response(result)
        restaurants = parsed.get("restaurants", [])[:10]  # Limit to 10
        
        # Format response
        if restaurants:
            response = f"Found {len(restaurants)} restaurants:\n\n"
            for i, r in enumerate(restaurants, 1):
                response += f"{i}. {r.get('name', 'Unknown')} - {r.get('cuisine', '')} - Rating: {r.get('rating', 'N/A')}\n"
        else:
            response = "No restaurants found matching your criteria."
        
        return {
            "restaurant_results": restaurants,
            "final_response": response
        }
    
    except Exception as e:
        return {
            "restaurant_results": [],
            "final_response": f"Error searching restaurants: {str(e)}"
        }

def retrieve_memory_agent(state: RestaurantDiscoveryState) -> dict:
    """Retrieve conversation history from memory"""
    if not memory_client or not MEMORY_ID:
        return {
            "final_response": "Memory not configured",
            "memory_status": "disabled"
        }
    
    try:
        user_id = state.get("user_id", "default_user")
        session_id = state.get("session_id", "default_session")
        
        events = memory_client.list_events(
            memory_id=MEMORY_ID,
            actor_id=user_id,
            session_id=session_id,
            max_results=10
        )
        
        if events:
            history = "# Search History\n\n"
            for i, event in enumerate(events, 1):
                history += f"{i}. {event}\n"
        else:
            history = "No previous searches found."
        
        return {
            "final_response": history,
            "memory_status": "retrieved"
        }
    except Exception as e:
        return {
            "final_response": f"Error retrieving history: {str(e)}",
            "memory_status": "error"
        }

def save_memory_agent(state: RestaurantDiscoveryState) -> dict:
    """Save search to memory"""
    if not memory_client or not MEMORY_ID:
        return {"memory_status": "disabled"}
    
    try:
        user_id = state.get("user_id", "default_user")
        session_id = state.get("session_id", "default_session")
        prompt = state.get("prompt", "")
        response = state.get("final_response", "")
        
        memory_client.save_conversation(
            memory_id=MEMORY_ID,
            actor_id=user_id,
            session_id=session_id,
            messages=[
                (prompt, "USER"),
                (response, "ASSISTANT")
            ]
        )
        
        return {"memory_status": "saved"}
    except Exception:
        return {"memory_status": "save_failed"}

# Build Workflow
def create_restaurant_workflow():
    """Create LangGraph workflow for restaurant discovery"""
    workflow = StateGraph(RestaurantDiscoveryState)
    
    # Add nodes
    workflow.add_node("entry_router", entry_router)
    workflow.add_node("restaurant_finder", restaurant_finder_agent)
    workflow.add_node("retrieve_memory", retrieve_memory_agent)
    workflow.add_node("save_memory", save_memory_agent)
    
    # Set entry point
    workflow.set_entry_point("entry_router")
    
    # Conditional routing
    workflow.add_conditional_edges(
        "entry_router",
        lambda state: state.get("next", "END"),
        {
            "restaurant_finder": "restaurant_finder",
            "retrieve_memory": "retrieve_memory",
            "END": END
        }
    )
    
    # Search flow
    workflow.add_edge("restaurant_finder", "save_memory")
    workflow.add_edge("save_memory", END)
    
    # History flow
    workflow.add_edge("retrieve_memory", END)
    
    return workflow.compile(checkpointer=MemorySaver())

# Create workflow
langgraph_workflow = create_restaurant_workflow()

# AgentCore Entrypoint
@app.entrypoint
def invoke(payload):
    """AgentCore Runtime entrypoint"""
    print(f"📥 Received payload: {payload}")
    
    prompt = payload.get("prompt", "")
    user_id = payload.get("user_id", "default_user")
    session_id = payload.get("session_id", f"session_{uuid.uuid4()}")
    correlation_id = f"req_{uuid.uuid4()}"
    
    if not prompt:
        return {"error": "No prompt provided", "status": "failed"}
    
    # Initial state
    initial_state = {
        "correlation_id": correlation_id,
        "user_id": user_id,
        "session_id": session_id,
        "messages": [],
        "prompt": prompt,
        "intent": "",
        "search_params": payload.get("search_params", {}),
        "restaurant_results": [],
        "final_response": "",
        "memory_status": ""
    }
    
    config = {"configurable": {"thread_id": f"thread_{random.randint(1000, 9999)}"}}
    
    try:
        final_state = langgraph_workflow.invoke(initial_state, config)
        
        return {
            "correlation_id": correlation_id,
            "intent": final_state.get("intent", ""),
            "restaurant_results": final_state.get("restaurant_results", []),
            "final_response": final_state.get("final_response", ""),
            "memory_status": final_state.get("memory_status", ""),
            "status": "success"
        }
    
    except Exception as e:
        print(f"❌ Workflow error: {str(e)}")
        return {"error": str(e), "status": "failed"}

print("✅ Restaurant Discovery Agent initialized")

if __name__ == "__main__":
    print("🚀 Starting Restaurant Discovery Agent...")
    print(f"🌐 Gateway URL: {GATEWAY_URL}")
    print(f"🧠 Memory ID: {MEMORY_ID or 'Not configured'}")
    app.run()
