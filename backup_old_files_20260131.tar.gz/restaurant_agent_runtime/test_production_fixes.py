#!/usr/bin/env python3
"""Test suite for production fixes: Response parsing, HITL, Enhanced validation"""

import sys
import json
from complete_booking_workflow import (
    langgraph_workflow,
    validate_phone,
    validate_date,
    validate_guests,
    parse_mcp_response
)
from datetime import datetime, timedelta

def test_response_parsing():
    """Test 1: Robust response parsing"""
    print("\n" + "="*60)
    print("TEST 1: Response Parsing (Multiple Field Fallbacks)")
    print("="*60)
    
    test_cases = [
        # Case 1: Direct JSON with totalAmount
        {
            "input": {"result": {"content": [{"text": '{"totalAmount": 50.0}'}]}},
            "expected_field": "totalAmount",
            "expected_value": 50.0
        },
        # Case 2: Nested body wrapper
        {
            "input": {"result": {"content": [{"text": '{"body": "{\\"tokenAmount\\": 75.5}"}'}]}},
            "expected_field": "tokenAmount",
            "expected_value": 75.5
        },
        # Case 3: Alternative field names
        {
            "input": {"result": {"content": [{"text": '{"amount": 100}'}]}},
            "expected_field": "amount",
            "expected_value": 100
        },
        # Case 4: Invalid JSON
        {
            "input": {"result": {"content": [{"text": 'invalid json'}]}},
            "expected_field": "error",
            "expected_value": "Invalid JSON response"
        }
    ]
    
    passed = 0
    for i, case in enumerate(test_cases, 1):
        result = parse_mcp_response(case["input"])
        if case["expected_field"] in result:
            print(f"✅ Case {i}: Parsed {case['expected_field']} successfully")
            passed += 1
        else:
            print(f"❌ Case {i}: Failed to parse {case['expected_field']}")
            print(f"   Got: {result}")
    
    print(f"\n📊 Parsing Tests: {passed}/{len(test_cases)} passed")
    return passed == len(test_cases)

def test_validation():
    """Test 2: Enhanced validation (phone, date, guests)"""
    print("\n" + "="*60)
    print("TEST 2: Enhanced Validation")
    print("="*60)
    
    # Phone validation
    print("\n📱 Phone Validation:")
    phone_tests = [
        ("+15551234567", True, "Valid 10-digit phone"),
        ("+1555123", False, "Too short (7 digits)"),
        ("555-123-4567", True, "Valid with dashes"),
        ("123", False, "Too short (3 digits)")
    ]
    
    phone_passed = 0
    for phone, expected, desc in phone_tests:
        valid, error = validate_phone(phone)
        if valid == expected:
            print(f"✅ {desc}: {phone}")
            phone_passed += 1
        else:
            print(f"❌ {desc}: {phone} - Expected {expected}, got {valid}")
    
    # Date validation
    print("\n📅 Date Validation:")
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    far_future = (datetime.now() + timedelta(days=100)).strftime("%Y-%m-%d")
    
    date_tests = [
        (tomorrow, True, "Tomorrow (valid)"),
        (yesterday, False, "Yesterday (past date)"),
        (far_future, False, "100 days out (>90 day limit)"),
        ("invalid-date", False, "Invalid format")
    ]
    
    date_passed = 0
    for date_str, expected, desc in date_tests:
        valid, error = validate_date(date_str)
        if valid == expected:
            print(f"✅ {desc}: {date_str}")
            date_passed += 1
        else:
            print(f"❌ {desc}: {date_str} - Expected {expected}, got {valid}")
            if error:
                print(f"   Error: {error}")
    
    # Guest validation
    print("\n👥 Guest Validation (HITL Trigger):")
    guest_tests = [
        (2, True, False, "2 guests (normal)"),
        (10, True, False, "10 guests (max without HITL)"),
        (15, True, True, "15 guests (requires HITL)"),
        (0, False, False, "0 guests (invalid)")
    ]
    
    guest_passed = 0
    for num, expected_valid, expected_hitl, desc in guest_tests:
        valid, error, hitl = validate_guests(num)
        if valid == expected_valid and hitl == expected_hitl:
            hitl_marker = "🔔 HITL" if hitl else ""
            print(f"✅ {desc} {hitl_marker}")
            guest_passed += 1
        else:
            print(f"❌ {desc} - Expected valid={expected_valid}, hitl={expected_hitl}, got valid={valid}, hitl={hitl}")
    
    total_tests = len(phone_tests) + len(date_tests) + len(guest_tests)
    total_passed = phone_passed + date_passed + guest_passed
    print(f"\n📊 Validation Tests: {total_passed}/{total_tests} passed")
    return total_passed == total_tests

def test_hitl_workflow():
    """Test 3: HITL workflow for large groups"""
    print("\n" + "="*60)
    print("TEST 3: HITL Workflow (Large Group Booking)")
    print("="*60)
    
    # Test case: 15 guests (should trigger HITL)
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    
    initial_state = {
        "correlation_id": "test_hitl_001",
        "user_id": "test_user",
        "session_id": "test_session",
        "messages": [],
        "prompt": "Book a table for 15 people at Italian Bistro tomorrow",
        "intent": "booking",
        "search_params": {"cuisine": "Italian"},
        "restaurant_results": [],
        "selected_restaurant": {"restaurantId": "rest_001", "name": "Italian Bistro"},
        "booking_intent": True,
        "booking_details": {
            "date": tomorrow,
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 15,
            "user_mobile": "+15551234567",
            "user_name": "Test User"
        },
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": "test_hitl_thread"}}
    
    try:
        print("\n🔄 Running workflow with 15 guests...")
        final_state = langgraph_workflow.invoke(initial_state, config)
        
        requires_hitl = final_state.get("requires_hitl", False)
        hitl_reason = final_state.get("hitl_reason", "")
        validation_errors = final_state.get("validation_errors", [])
        
        print(f"\n📋 Results:")
        print(f"   Requires HITL: {requires_hitl}")
        print(f"   HITL Reason: {hitl_reason}")
        print(f"   Validation Errors: {validation_errors}")
        print(f"   Final Response: {final_state.get('final_response', '')[:200]}")
        
        if requires_hitl and "15 guests" in hitl_reason:
            print("\n✅ HITL correctly triggered for large group")
            return True
        else:
            print("\n❌ HITL not triggered as expected")
            return False
    
    except Exception as e:
        print(f"\n❌ Workflow error: {str(e)}")
        return False

def test_validation_errors():
    """Test 4: Validation error handling"""
    print("\n" + "="*60)
    print("TEST 4: Validation Error Handling")
    print("="*60)
    
    # Test case: Invalid phone and past date
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    initial_state = {
        "correlation_id": "test_validation_001",
        "user_id": "test_user",
        "session_id": "test_session",
        "messages": [],
        "prompt": "Book a table",
        "intent": "booking",
        "search_params": {},
        "restaurant_results": [],
        "selected_restaurant": {"restaurantId": "rest_001", "name": "Test Restaurant"},
        "booking_intent": True,
        "booking_details": {
            "date": yesterday,
            "time": "19:00",
            "meal_type": "Dinner",
            "no_of_guests": 2,
            "user_mobile": "123",  # Invalid: too short
            "user_name": "Test User"
        },
        "user_details": {},
        "token_amount": 0,
        "booking_result": {},
        "payment_result": {},
        "compensation_stack": [],
        "final_response": "",
        "memory_status": "",
        "requires_hitl": False,
        "hitl_reason": "",
        "validation_errors": []
    }
    
    config = {"configurable": {"thread_id": "test_validation_thread"}}
    
    try:
        print("\n🔄 Running workflow with invalid data...")
        final_state = langgraph_workflow.invoke(initial_state, config)
        
        validation_errors = final_state.get("validation_errors", [])
        final_response = final_state.get("final_response", "")
        
        print(f"\n📋 Results:")
        print(f"   Validation Errors: {len(validation_errors)}")
        for i, error in enumerate(validation_errors, 1):
            print(f"      {i}. {error}")
        print(f"   Final Response: {final_response[:200]}")
        
        # Should have 2 errors: phone and date
        if len(validation_errors) >= 2 and "❌" in final_response:
            print("\n✅ Validation errors correctly caught and reported")
            return True
        else:
            print("\n❌ Validation errors not properly handled")
            return False
    
    except Exception as e:
        print(f"\n❌ Workflow error: {str(e)}")
        return False

def main():
    print("\n" + "="*60)
    print("🧪 PRODUCTION FIXES TEST SUITE")
    print("="*60)
    print("Testing: Response Parsing, HITL, Enhanced Validation")
    
    results = {
        "Response Parsing": test_response_parsing(),
        "Enhanced Validation": test_validation(),
        "HITL Workflow": test_hitl_workflow(),
        "Validation Errors": test_validation_errors()
    }
    
    print("\n" + "="*60)
    print("📊 FINAL RESULTS")
    print("="*60)
    
    for test_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    total_passed = sum(results.values())
    total_tests = len(results)
    
    print(f"\n🎯 Overall: {total_passed}/{total_tests} test suites passed")
    
    if total_passed == total_tests:
        print("\n🎉 ALL PRODUCTION FIXES VERIFIED!")
        return 0
    else:
        print("\n⚠️  Some tests failed - review output above")
        return 1

if __name__ == "__main__":
    sys.exit(main())
