#!/bin/bash
set -e

echo "🐳 Building Docker image locally..."
docker build -t restaurant-agent-local:latest .

echo ""
echo "🚀 Starting agent runtime locally on port 9000..."
echo "Press Ctrl+C to stop"
echo ""

docker run -it --rm \
  -p 9000:9000 \
  -e AWS_REGION=us-east-1 \
  -e AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID}" \
  -e AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY}" \
  -e AWS_SESSION_TOKEN="${AWS_SESSION_TOKEN:-}" \
  restaurant-agent-local:latest
