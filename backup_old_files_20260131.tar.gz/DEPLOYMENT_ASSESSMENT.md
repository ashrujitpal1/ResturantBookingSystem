# Deployment Readiness Assessment

## Current Status

### ⚠️ CRITICAL ISSUE: Wrong Entrypoint

**Current Configuration** (`.bedrock_agentcore.yaml`):
```yaml
entrypoint: restaurant_agent_runtime/restaurant_workflow.py  # ❌ Phase 1 only
```

**Should Be**:
```yaml
entrypoint: restaurant_agent_runtime/complete_booking_workflow.py  # ✅ All 3 phases
```

### What's Deployed vs What Should Be Deployed

| Component | Currently Deployed | Should Deploy | Status |
|-----------|-------------------|---------------|---------|
| Entrypoint | `restaurant_workflow.py` | `complete_booking_workflow.py` | ❌ Wrong |
| Phase 1 (Search) | ✅ Yes | ✅ Yes | ✅ OK |
| Phase 2 (Booking) | ❌ No | ✅ Yes | ❌ Missing |
| Phase 3 (Memory) | ⚠️ Partial | ✅ Yes | ⚠️ Incomplete |
| Production Patterns | ❌ No | ✅ Yes (5/10) | ❌ Missing |

---

## Deployment Script Analysis

### 1. `deploy-complete.sh` ✅ RECOMMENDED

**What it does**:
1. ✅ Uploads prompts to S3
2. ✅ Updates `.bedrock_agentcore.yaml` to use `complete_booking_workflow.py`
3. ✅ Deploys complete workflow (all 3 phases)
4. ✅ Includes all 5 production patterns

**Pros**:
- Most comprehensive
- Handles prompt versioning
- Updates config correctly
- Interactive confirmation

**Cons**:
- Hardcodes config (overwrites existing `.bedrock_agentcore.yaml`)
- Doesn't enable memory (still sets `mode: NO_MEMORY`)

**Verdict**: ✅ **USE THIS** (with modifications)

---

### 2. `deploy-production.sh` ⚠️ INFRASTRUCTURE ONLY

**What it does**:
1. Creates DynamoDB IdempotencyCache table
2. Deploys Lambda functions via SAM
3. Verifies infrastructure

**Pros**:
- Sets up backend infrastructure
- Creates idempotency table

**Cons**:
- Doesn't deploy AgentCore runtime
- Only for Lambda backend, not agent

**Verdict**: ⚠️ **RUN FIRST** (for infrastructure), then run `deploy-complete.sh`

---

### 3. `deploy_restaurant_agent.py` ⚠️ OUTDATED

**What it does**:
1. Creates IAM roles
2. Creates memory store
3. Deploys using Starter Toolkit

**Pros**:
- Creates memory automatically
- Comprehensive setup

**Cons**:
- Uses old entrypoint (`restaurant_workflow.py`)
- Doesn't include production patterns
- Python-based (less flexible)

**Verdict**: ⚠️ **DON'T USE** (outdated)

---

## Recommended Deployment Steps

### Step 1: Deploy Infrastructure (Backend)

```bash
./deploy-production.sh
```

**Creates**:
- DynamoDB `IdempotencyCache` table
- Lambda functions (bookATable, paymentAPI, etc.)
- SAM stack

**Time**: ~5 minutes

---

### Step 2: Fix `deploy-complete.sh`

The script needs 2 modifications:

#### Modification 1: Don't Overwrite Config
Remove the hardcoded config section (lines 30-90) and use `sed` instead:

```bash
# Instead of cat > .bedrock_agentcore.yaml
# Use sed to update entrypoint only
sed -i.bak 's|entrypoint: .*/restaurant_workflow.py|entrypoint: /Users/USER/Work/AI/AgentCore/ResturantBookingSystem/restaurant_agent_runtime/complete_booking_workflow.py|' .bedrock_agentcore.yaml
```

#### Modification 2: Enable Memory
Add memory configuration update:

```bash
# Update memory mode
sed -i.bak 's|mode: NO_MEMORY|mode: MEMORY_ENABLED|' .bedrock_agentcore.yaml
```

---

### Step 3: Run Modified Deployment

```bash
./deploy-complete.sh
```

**Deploys**:
- ✅ Versioned prompts to S3
- ✅ Complete booking workflow (all 3 phases)
- ✅ All 5 production patterns
- ✅ Memory enabled (if modified)

**Time**: ~10 minutes

---

## What's Missing from Scripts

### 1. Memory Store Creation ❌

**None of the scripts create memory store!**

You need to run separately:
```bash
python enable_memory.py
```

Or manually:
```bash
aws bedrock-agentcore create-memory \
  --memory-name restaurant-booking-memory \
  --retention-days 30 \
  --region us-east-1
```

### 2. Environment Variables ❌

Scripts don't set:
```bash
export MEMORY_ID=<memory_id>
export PROMPT_BUCKET=restaurant-booking-prompts
export PROMPT_VERSION=1.0.0
```

### 3. IAM Permissions ⚠️

Execution role needs memory permissions:
```json
{
  "Effect": "Allow",
  "Action": [
    "bedrock-agentcore:SaveConversation",
    "bedrock-agentcore:ListEvents"
  ],
  "Resource": "arn:aws:bedrock-agentcore:*:*:memory/*"
}
```

---

## Complete Deployment Checklist

### Pre-Deployment
- [ ] AWS credentials configured
- [ ] Region set to `us-east-1`
- [ ] S3 bucket `restaurant-booking-prompts` exists
- [ ] IAM role has Bedrock + Memory permissions

### Infrastructure
- [ ] Run `./deploy-production.sh` (Lambda + DynamoDB)
- [ ] Verify Lambda functions deployed
- [ ] Verify IdempotencyCache table created

### Memory Setup
- [ ] Run `python enable_memory.py`
- [ ] Save `MEMORY_ID` from output
- [ ] Update `.bedrock_agentcore.yaml` with memory config

### Agent Deployment
- [ ] Modify `deploy-complete.sh` (see Step 2 above)
- [ ] Run `./deploy-complete.sh`
- [ ] Verify entrypoint is `complete_booking_workflow.py`
- [ ] Verify memory mode is `MEMORY_ENABLED`

### Post-Deployment
- [ ] Test Phase 1: Search restaurants
- [ ] Test Phase 2: Book table + payment
- [ ] Test Phase 3: Memory retrieval
- [ ] Check CloudWatch logs
- [ ] Verify cost metrics

---

## Quick Fix Script

I'll create a fixed version that does everything:
