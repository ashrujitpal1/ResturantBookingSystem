#!/bin/bash
# Deploy Complete Restaurant Booking System

set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🚀 Restaurant Booking System - Complete Deployment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Deploying:"
echo "  ✅ Phase 1: Restaurant Discovery"
echo "  ✅ Phase 2: Booking & Payment (SAGA)"
echo "  ✅ Phase 3: Memory & History (PII scrubbing)"
echo "  ✅ 5 Production Patterns"
echo ""

AGENT_NAME="restaurant_discovery_agent"

# Step 1: Infrastructure
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📦 Step 1/4: Backend Infrastructure"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "deploy-production.sh" ]; then
    ./deploy-production.sh
else
    echo "⚠️  Skipping (deploy-production.sh not found)"
fi

# Step 2: Memory (optional - skip if fails)
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧠 Step 2/4: Memory Store"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
./setup-memory.sh || echo "⚠️  Memory setup failed, continuing without memory (Phase 3 disabled)"

# Step 3: Prompts
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📤 Step 3/4: Upload Prompts"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "upload_prompts_to_s3.py" ]; then
    python3 upload_prompts_to_s3.py || echo "⚠️  Using embedded defaults"
else
    echo "⚠️  Skipping (will use embedded defaults)"
fi

# Step 4: Deploy Agent
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🚀 Step 4/4: Deploy Agent"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Deploying to AgentCore (5-10 minutes)..."
echo ""

python3 deploy-agent.py

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ DEPLOYMENT COMPLETE!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📦 Deployed:"
echo "   ✅ Phase 1: Restaurant Search"
echo "   ✅ Phase 2: Booking & Payment"
echo "   ⚠️  Phase 3: Memory (disabled - create manually)"
echo "   ✅ 5 production patterns"
echo "   ✅ Entrypoint: complete_booking_workflow.py"
echo ""
echo "🧪 Test:"
echo "   python3 test_deployed_agent.py"
echo ""
echo "📊 Logs:"
echo "   aws logs tail /aws/bedrock-agentcore/$AGENT_NAME --follow"
echo ""
