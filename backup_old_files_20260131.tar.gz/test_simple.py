#!/usr/bin/env python3
"""Test the deployed agent directly"""

import boto3
import json

# Use the deployed agent ARN
AGENT_ARN = "arn:aws:bedrock-agentcore:us-east-1:696072349808:runtime/restaurant_discovery_agent-BiIqCDHZrl"

client = boto3.client('bedrock-agent-runtime', region_name='us-east-1')

print("🧪 Testing Deployed Restaurant Booking System")
print("=" * 80)
print(f"Agent: {AGENT_ARN}")
print()

# Test Phase 1: Restaurant Search
test_payload = {
    "prompt": "Find Italian restaurants in New York",
    "user_id": "test_user_001",
    "search_params": {"city": "New York", "cuisine": "Italian"}
}

print("📥 Test: Restaurant Search")
print(f"Payload: {test_payload['prompt']}")

try:
    response = client.invoke_agent(
        agentId=AGENT_ARN.split('/')[-1],
        agentAliasId='DEFAULT',
        sessionId='test-session-001',
        inputText=json.dumps(test_payload)
    )
    
    # Parse response
    result = ""
    for event in response['completion']:
        if 'chunk' in event:
            result += event['chunk']['bytes'].decode('utf-8')
    
    print(f"\n✅ Response:\n{result[:500]}...")
    print("\n✅ Test PASSED")
    
except Exception as e:
    print(f"\n❌ Test FAILED: {e}")

print("\n" + "=" * 80)
